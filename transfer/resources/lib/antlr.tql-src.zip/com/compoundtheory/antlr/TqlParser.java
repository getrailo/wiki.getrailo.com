// $ANTLR 3.0b7 T:\\transfer-root\\antlr/Tql.g 2007-03-15 16:30:49

package com.compoundtheory.antlr;

/**
* Transfer Query Language Parser
*
* @author Mark Mandel
*/


import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;


import org.antlr.runtime.tree.*;

public class TqlParser extends Parser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "ON_COMPOSITE", "ON_IDENTIFIER", "SELECT", "COMMA", "ASTERISK", "PROPERTY_IDENTIFIER", "AS", "ALIAS", "FROM", "CLASS_IDENTIFIER", "JOIN", "LEFT", "RIGHT", "OUTER", "ON", "BOOLEAN_LOGIC", "WHERE", "LEFT_PAREN", "RIGHT_PAREN", "OPERATOR", "MAPPED_PARAM", "IS", "NOT", "NULL", "IN", "ORDER", "BY", "ASC_DESC", "LETTER", "DIGIT", "IDENTIFIER", "WS"
    };
    public static final int COMMA=7;
    public static final int LEFT_PAREN=21;
    public static final int LETTER=32;
    public static final int AS=10;
    public static final int WS=35;
    public static final int IS=25;
    public static final int CLASS_IDENTIFIER=13;
    public static final int PROPERTY_IDENTIFIER=9;
    public static final int ASC_DESC=31;
    public static final int ALIAS=11;
    public static final int MAPPED_PARAM=24;
    public static final int ON=18;
    public static final int IN=28;
    public static final int ORDER=29;
    public static final int BY=30;
    public static final int RIGHT=16;
    public static final int ON_COMPOSITE=4;
    public static final int BOOLEAN_LOGIC=19;
    public static final int EOF=-1;
    public static final int SELECT=6;
    public static final int NULL=27;
    public static final int ASTERISK=8;
    public static final int DIGIT=33;
    public static final int LEFT=15;
    public static final int IDENTIFIER=34;
    public static final int OPERATOR=23;
    public static final int ON_IDENTIFIER=5;
    public static final int JOIN=14;
    public static final int NOT=26;
    public static final int RIGHT_PAREN=22;
    public static final int OUTER=17;
    public static final int WHERE=20;
    public static final int FROM=12;

        public TqlParser(TokenStream input) {
            super(input);
        }
        
    protected TreeAdaptor adaptor = new CommonTreeAdaptor();

    public void setTreeAdaptor(TreeAdaptor adaptor) {
        this.adaptor = adaptor;
    }
    public TreeAdaptor getTreeAdaptor() {
        return adaptor;
    }

    public String[] getTokenNames() { return tokenNames; }
    public String getGrammarFileName() { return "T:\\transfer-root\\antlr/Tql.g"; }

    
    	private RecognitionException recognitionException;
    	private String errorMessage;
    	
    	public void displayRecognitionError(String[] tokenNames, RecognitionException e)
    	{
    		if(!hasError())
    		{
    			setRecognitionException(e);
    			setErrorMessage(getErrorMessage(e, tokenNames));		
    		}
    	}
    	
    	public RecognitionException getRecognitionException()
    	{
    		return recognitionException;
    	}
    	
    	private void setRecognitionException(RecognitionException e)
    	{
    		recognitionException = e;
    	}
    	
    	public boolean hasError()
    	{
    		return (getRecognitionException() != null);
    	}
    	
    	public String getErrorMessage()
    	{
    		return errorMessage;
    	}
    	
    	private void setErrorMessage(String error)
    	{
    		errorMessage = error;
    	}


    public static class selectStatement_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start selectStatement
    // T:\\transfer-root\\antlr/Tql.g:140:1: selectStatement : ( fromExpression^ | selectExpression^ ) ( orderByStatement )? ;
    public selectStatement_return selectStatement() throws RecognitionException {
        selectStatement_return retval = new selectStatement_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        fromExpression_return fromExpression1 = null;

        selectExpression_return selectExpression2 = null;

        orderByStatement_return orderByStatement3 = null;



        try {
            // T:\\transfer-root\\antlr/Tql.g:142:2: ( ( fromExpression^ | selectExpression^ ) ( orderByStatement )? )
            // T:\\transfer-root\\antlr/Tql.g:142:2: ( fromExpression^ | selectExpression^ ) ( orderByStatement )?
            {
            root_0 = (Object)adaptor.nil();

            // T:\\transfer-root\\antlr/Tql.g:142:2: ( fromExpression^ | selectExpression^ )
            int alt1=2;
            int LA1_0 = input.LA(1);
            if ( (LA1_0==FROM) ) {
                alt1=1;
            }
            else if ( (LA1_0==SELECT) ) {
                alt1=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("142:2: ( fromExpression^ | selectExpression^ )", 1, 0, input);

                throw nvae;
            }
            switch (alt1) {
                case 1 :
                    // T:\\transfer-root\\antlr/Tql.g:142:4: fromExpression^
                    {
                    pushFollow(FOLLOW_fromExpression_in_selectStatement78);
                    fromExpression1=fromExpression();
                    _fsp--;

                    root_0 = (Object)adaptor.becomeRoot(fromExpression1.getTree(), root_0);

                    }
                    break;
                case 2 :
                    // T:\\transfer-root\\antlr/Tql.g:142:22: selectExpression^
                    {
                    pushFollow(FOLLOW_selectExpression_in_selectStatement83);
                    selectExpression2=selectExpression();
                    _fsp--;

                    root_0 = (Object)adaptor.becomeRoot(selectExpression2.getTree(), root_0);

                    }
                    break;

            }

            // T:\\transfer-root\\antlr/Tql.g:143:2: ( orderByStatement )?
            int alt2=2;
            int LA2_0 = input.LA(1);
            if ( (LA2_0==ORDER) ) {
                alt2=1;
            }
            switch (alt2) {
                case 1 :
                    // T:\\transfer-root\\antlr/Tql.g:143:2: orderByStatement
                    {
                    pushFollow(FOLLOW_orderByStatement_in_selectStatement89);
                    orderByStatement3=orderByStatement();
                    _fsp--;

                    adaptor.addChild(root_0, orderByStatement3.getTree());

                    }
                    break;

            }


            }

            retval.stop = input.LT(-1);

                retval.tree = (Object)adaptor.rulePostProcessing(root_0);
                adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end selectStatement

    public static class fromExpression_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start fromExpression
    // T:\\transfer-root\\antlr/Tql.g:146:1: fromExpression : fromStatement^ ( whereStatement )? ;
    public fromExpression_return fromExpression() throws RecognitionException {
        fromExpression_return retval = new fromExpression_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        fromStatement_return fromStatement4 = null;

        whereStatement_return whereStatement5 = null;



        try {
            // T:\\transfer-root\\antlr/Tql.g:148:2: ( fromStatement^ ( whereStatement )? )
            // T:\\transfer-root\\antlr/Tql.g:148:2: fromStatement^ ( whereStatement )?
            {
            root_0 = (Object)adaptor.nil();

            pushFollow(FOLLOW_fromStatement_in_fromExpression103);
            fromStatement4=fromStatement();
            _fsp--;

            root_0 = (Object)adaptor.becomeRoot(fromStatement4.getTree(), root_0);
            // T:\\transfer-root\\antlr/Tql.g:149:2: ( whereStatement )?
            int alt3=2;
            int LA3_0 = input.LA(1);
            if ( (LA3_0==WHERE) ) {
                alt3=1;
            }
            switch (alt3) {
                case 1 :
                    // T:\\transfer-root\\antlr/Tql.g:149:2: whereStatement
                    {
                    pushFollow(FOLLOW_whereStatement_in_fromExpression107);
                    whereStatement5=whereStatement();
                    _fsp--;

                    adaptor.addChild(root_0, whereStatement5.getTree());

                    }
                    break;

            }


            }

            retval.stop = input.LT(-1);

                retval.tree = (Object)adaptor.rulePostProcessing(root_0);
                adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end fromExpression

    public static class selectExpression_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start selectExpression
    // T:\\transfer-root\\antlr/Tql.g:152:1: selectExpression : selectHeader^ fromStatement ( whereStatement )? ;
    public selectExpression_return selectExpression() throws RecognitionException {
        selectExpression_return retval = new selectExpression_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        selectHeader_return selectHeader6 = null;

        fromStatement_return fromStatement7 = null;

        whereStatement_return whereStatement8 = null;



        try {
            // T:\\transfer-root\\antlr/Tql.g:154:2: ( selectHeader^ fromStatement ( whereStatement )? )
            // T:\\transfer-root\\antlr/Tql.g:154:2: selectHeader^ fromStatement ( whereStatement )?
            {
            root_0 = (Object)adaptor.nil();

            pushFollow(FOLLOW_selectHeader_in_selectExpression121);
            selectHeader6=selectHeader();
            _fsp--;

            root_0 = (Object)adaptor.becomeRoot(selectHeader6.getTree(), root_0);
            pushFollow(FOLLOW_fromStatement_in_selectExpression125);
            fromStatement7=fromStatement();
            _fsp--;

            adaptor.addChild(root_0, fromStatement7.getTree());
            // T:\\transfer-root\\antlr/Tql.g:156:2: ( whereStatement )?
            int alt4=2;
            int LA4_0 = input.LA(1);
            if ( (LA4_0==WHERE) ) {
                alt4=1;
            }
            switch (alt4) {
                case 1 :
                    // T:\\transfer-root\\antlr/Tql.g:156:2: whereStatement
                    {
                    pushFollow(FOLLOW_whereStatement_in_selectExpression128);
                    whereStatement8=whereStatement();
                    _fsp--;

                    adaptor.addChild(root_0, whereStatement8.getTree());

                    }
                    break;

            }


            }

            retval.stop = input.LT(-1);

                retval.tree = (Object)adaptor.rulePostProcessing(root_0);
                adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end selectExpression

    public static class selectHeader_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start selectHeader
    // T:\\transfer-root\\antlr/Tql.g:159:1: selectHeader : SELECT^ propertyStatement ( COMMA propertyStatement )* ;
    public selectHeader_return selectHeader() throws RecognitionException {
        selectHeader_return retval = new selectHeader_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token SELECT9=null;
        Token COMMA11=null;
        propertyStatement_return propertyStatement10 = null;

        propertyStatement_return propertyStatement12 = null;


        Object SELECT9_tree=null;
        Object COMMA11_tree=null;

        try {
            // T:\\transfer-root\\antlr/Tql.g:161:2: ( SELECT^ propertyStatement ( COMMA propertyStatement )* )
            // T:\\transfer-root\\antlr/Tql.g:161:2: SELECT^ propertyStatement ( COMMA propertyStatement )*
            {
            root_0 = (Object)adaptor.nil();

            SELECT9=(Token)input.LT(1);
            match(input,SELECT,FOLLOW_SELECT_in_selectHeader142); 
            SELECT9_tree = (Object)adaptor.create(SELECT9);
            root_0 = (Object)adaptor.becomeRoot(SELECT9_tree, root_0);

            pushFollow(FOLLOW_propertyStatement_in_selectHeader145);
            propertyStatement10=propertyStatement();
            _fsp--;

            adaptor.addChild(root_0, propertyStatement10.getTree());
            // T:\\transfer-root\\antlr/Tql.g:161:28: ( COMMA propertyStatement )*
            loop5:
            do {
                int alt5=2;
                int LA5_0 = input.LA(1);
                if ( (LA5_0==COMMA) ) {
                    alt5=1;
                }


                switch (alt5) {
            	case 1 :
            	    // T:\\transfer-root\\antlr/Tql.g:161:29: COMMA propertyStatement
            	    {
            	    COMMA11=(Token)input.LT(1);
            	    match(input,COMMA,FOLLOW_COMMA_in_selectHeader148); 
            	    COMMA11_tree = (Object)adaptor.create(COMMA11);
            	    adaptor.addChild(root_0, COMMA11_tree);

            	    pushFollow(FOLLOW_propertyStatement_in_selectHeader150);
            	    propertyStatement12=propertyStatement();
            	    _fsp--;

            	    adaptor.addChild(root_0, propertyStatement12.getTree());

            	    }
            	    break;

            	default :
            	    break loop5;
                }
            } while (true);


            }

            retval.stop = input.LT(-1);

                retval.tree = (Object)adaptor.rulePostProcessing(root_0);
                adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end selectHeader

    public static class propertyStatement_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start propertyStatement
    // T:\\transfer-root\\antlr/Tql.g:164:1: propertyStatement : ( propertyClause | ASTERISK );
    public propertyStatement_return propertyStatement() throws RecognitionException {
        propertyStatement_return retval = new propertyStatement_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token ASTERISK14=null;
        propertyClause_return propertyClause13 = null;


        Object ASTERISK14_tree=null;

        try {
            // T:\\transfer-root\\antlr/Tql.g:166:2: ( propertyClause | ASTERISK )
            int alt6=2;
            int LA6_0 = input.LA(1);
            if ( (LA6_0==PROPERTY_IDENTIFIER) ) {
                alt6=1;
            }
            else if ( (LA6_0==ASTERISK) ) {
                alt6=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("164:1: propertyStatement : ( propertyClause | ASTERISK );", 6, 0, input);

                throw nvae;
            }
            switch (alt6) {
                case 1 :
                    // T:\\transfer-root\\antlr/Tql.g:166:2: propertyClause
                    {
                    root_0 = (Object)adaptor.nil();

                    pushFollow(FOLLOW_propertyClause_in_propertyStatement164);
                    propertyClause13=propertyClause();
                    _fsp--;

                    adaptor.addChild(root_0, propertyClause13.getTree());

                    }
                    break;
                case 2 :
                    // T:\\transfer-root\\antlr/Tql.g:166:19: ASTERISK
                    {
                    root_0 = (Object)adaptor.nil();

                    ASTERISK14=(Token)input.LT(1);
                    match(input,ASTERISK,FOLLOW_ASTERISK_in_propertyStatement168); 
                    ASTERISK14_tree = (Object)adaptor.create(ASTERISK14);
                    adaptor.addChild(root_0, ASTERISK14_tree);


                    }
                    break;

            }
            retval.stop = input.LT(-1);

                retval.tree = (Object)adaptor.rulePostProcessing(root_0);
                adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end propertyStatement

    public static class propertyClause_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start propertyClause
    // T:\\transfer-root\\antlr/Tql.g:169:1: propertyClause : PROPERTY_IDENTIFIER^ ( AS ALIAS )? ;
    public propertyClause_return propertyClause() throws RecognitionException {
        propertyClause_return retval = new propertyClause_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token PROPERTY_IDENTIFIER15=null;
        Token AS16=null;
        Token ALIAS17=null;

        Object PROPERTY_IDENTIFIER15_tree=null;
        Object AS16_tree=null;
        Object ALIAS17_tree=null;

        try {
            // T:\\transfer-root\\antlr/Tql.g:171:2: ( PROPERTY_IDENTIFIER^ ( AS ALIAS )? )
            // T:\\transfer-root\\antlr/Tql.g:171:2: PROPERTY_IDENTIFIER^ ( AS ALIAS )?
            {
            root_0 = (Object)adaptor.nil();

            PROPERTY_IDENTIFIER15=(Token)input.LT(1);
            match(input,PROPERTY_IDENTIFIER,FOLLOW_PROPERTY_IDENTIFIER_in_propertyClause181); 
            PROPERTY_IDENTIFIER15_tree = (Object)adaptor.create(PROPERTY_IDENTIFIER15);
            root_0 = (Object)adaptor.becomeRoot(PROPERTY_IDENTIFIER15_tree, root_0);

            // T:\\transfer-root\\antlr/Tql.g:171:23: ( AS ALIAS )?
            int alt7=2;
            int LA7_0 = input.LA(1);
            if ( (LA7_0==AS) ) {
                alt7=1;
            }
            switch (alt7) {
                case 1 :
                    // T:\\transfer-root\\antlr/Tql.g:171:24: AS ALIAS
                    {
                    AS16=(Token)input.LT(1);
                    match(input,AS,FOLLOW_AS_in_propertyClause185); 
                    AS16_tree = (Object)adaptor.create(AS16);
                    adaptor.addChild(root_0, AS16_tree);

                    ALIAS17=(Token)input.LT(1);
                    match(input,ALIAS,FOLLOW_ALIAS_in_propertyClause187); 
                    ALIAS17_tree = (Object)adaptor.create(ALIAS17);
                    adaptor.addChild(root_0, ALIAS17_tree);


                    }
                    break;

            }


            }

            retval.stop = input.LT(-1);

                retval.tree = (Object)adaptor.rulePostProcessing(root_0);
                adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end propertyClause

    public static class fromStatement_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start fromStatement
    // T:\\transfer-root\\antlr/Tql.g:174:1: fromStatement : FROM^ classClause ( joinClause )* ;
    public fromStatement_return fromStatement() throws RecognitionException {
        fromStatement_return retval = new fromStatement_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token FROM18=null;
        classClause_return classClause19 = null;

        joinClause_return joinClause20 = null;


        Object FROM18_tree=null;

        try {
            // T:\\transfer-root\\antlr/Tql.g:176:2: ( FROM^ classClause ( joinClause )* )
            // T:\\transfer-root\\antlr/Tql.g:176:2: FROM^ classClause ( joinClause )*
            {
            root_0 = (Object)adaptor.nil();

            FROM18=(Token)input.LT(1);
            match(input,FROM,FOLLOW_FROM_in_fromStatement201); 
            FROM18_tree = (Object)adaptor.create(FROM18);
            root_0 = (Object)adaptor.becomeRoot(FROM18_tree, root_0);

            pushFollow(FOLLOW_classClause_in_fromStatement204);
            classClause19=classClause();
            _fsp--;

            adaptor.addChild(root_0, classClause19.getTree());
            // T:\\transfer-root\\antlr/Tql.g:176:20: ( joinClause )*
            loop8:
            do {
                int alt8=2;
                int LA8_0 = input.LA(1);
                if ( ((LA8_0>=JOIN && LA8_0<=OUTER)) ) {
                    alt8=1;
                }


                switch (alt8) {
            	case 1 :
            	    // T:\\transfer-root\\antlr/Tql.g:176:21: joinClause
            	    {
            	    pushFollow(FOLLOW_joinClause_in_fromStatement207);
            	    joinClause20=joinClause();
            	    _fsp--;

            	    adaptor.addChild(root_0, joinClause20.getTree());

            	    }
            	    break;

            	default :
            	    break loop8;
                }
            } while (true);


            }

            retval.stop = input.LT(-1);

                retval.tree = (Object)adaptor.rulePostProcessing(root_0);
                adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end fromStatement

    public static class classClause_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start classClause
    // T:\\transfer-root\\antlr/Tql.g:179:1: classClause : CLASS_IDENTIFIER^ ( AS ALIAS )? ;
    public classClause_return classClause() throws RecognitionException {
        classClause_return retval = new classClause_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token CLASS_IDENTIFIER21=null;
        Token AS22=null;
        Token ALIAS23=null;

        Object CLASS_IDENTIFIER21_tree=null;
        Object AS22_tree=null;
        Object ALIAS23_tree=null;

        try {
            // T:\\transfer-root\\antlr/Tql.g:181:2: ( CLASS_IDENTIFIER^ ( AS ALIAS )? )
            // T:\\transfer-root\\antlr/Tql.g:181:2: CLASS_IDENTIFIER^ ( AS ALIAS )?
            {
            root_0 = (Object)adaptor.nil();

            CLASS_IDENTIFIER21=(Token)input.LT(1);
            match(input,CLASS_IDENTIFIER,FOLLOW_CLASS_IDENTIFIER_in_classClause222); 
            CLASS_IDENTIFIER21_tree = (Object)adaptor.create(CLASS_IDENTIFIER21);
            root_0 = (Object)adaptor.becomeRoot(CLASS_IDENTIFIER21_tree, root_0);

            // T:\\transfer-root\\antlr/Tql.g:181:20: ( AS ALIAS )?
            int alt9=2;
            int LA9_0 = input.LA(1);
            if ( (LA9_0==AS) ) {
                alt9=1;
            }
            switch (alt9) {
                case 1 :
                    // T:\\transfer-root\\antlr/Tql.g:181:21: AS ALIAS
                    {
                    AS22=(Token)input.LT(1);
                    match(input,AS,FOLLOW_AS_in_classClause226); 
                    AS22_tree = (Object)adaptor.create(AS22);
                    adaptor.addChild(root_0, AS22_tree);

                    ALIAS23=(Token)input.LT(1);
                    match(input,ALIAS,FOLLOW_ALIAS_in_classClause228); 
                    ALIAS23_tree = (Object)adaptor.create(ALIAS23);
                    adaptor.addChild(root_0, ALIAS23_tree);


                    }
                    break;

            }


            }

            retval.stop = input.LT(-1);

                retval.tree = (Object)adaptor.rulePostProcessing(root_0);
                adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end classClause

    public static class joinClause_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start joinClause
    // T:\\transfer-root\\antlr/Tql.g:184:1: joinClause : ( outerClause )? JOIN^ classClause ( onClause )? ;
    public joinClause_return joinClause() throws RecognitionException {
        joinClause_return retval = new joinClause_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token JOIN25=null;
        outerClause_return outerClause24 = null;

        classClause_return classClause26 = null;

        onClause_return onClause27 = null;


        Object JOIN25_tree=null;

        try {
            // T:\\transfer-root\\antlr/Tql.g:186:2: ( ( outerClause )? JOIN^ classClause ( onClause )? )
            // T:\\transfer-root\\antlr/Tql.g:186:2: ( outerClause )? JOIN^ classClause ( onClause )?
            {
            root_0 = (Object)adaptor.nil();

            // T:\\transfer-root\\antlr/Tql.g:186:2: ( outerClause )?
            int alt10=2;
            int LA10_0 = input.LA(1);
            if ( ((LA10_0>=LEFT && LA10_0<=OUTER)) ) {
                alt10=1;
            }
            switch (alt10) {
                case 1 :
                    // T:\\transfer-root\\antlr/Tql.g:186:3: outerClause
                    {
                    pushFollow(FOLLOW_outerClause_in_joinClause243);
                    outerClause24=outerClause();
                    _fsp--;

                    adaptor.addChild(root_0, outerClause24.getTree());

                    }
                    break;

            }

            JOIN25=(Token)input.LT(1);
            match(input,JOIN,FOLLOW_JOIN_in_joinClause247); 
            JOIN25_tree = (Object)adaptor.create(JOIN25);
            root_0 = (Object)adaptor.becomeRoot(JOIN25_tree, root_0);

            pushFollow(FOLLOW_classClause_in_joinClause250);
            classClause26=classClause();
            _fsp--;

            adaptor.addChild(root_0, classClause26.getTree());
            // T:\\transfer-root\\antlr/Tql.g:186:35: ( onClause )?
            int alt11=2;
            int LA11_0 = input.LA(1);
            if ( (LA11_0==ON) ) {
                alt11=1;
            }
            switch (alt11) {
                case 1 :
                    // T:\\transfer-root\\antlr/Tql.g:186:36: onClause
                    {
                    pushFollow(FOLLOW_onClause_in_joinClause253);
                    onClause27=onClause();
                    _fsp--;

                    adaptor.addChild(root_0, onClause27.getTree());

                    }
                    break;

            }


            }

            retval.stop = input.LT(-1);

                retval.tree = (Object)adaptor.rulePostProcessing(root_0);
                adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end joinClause

    public static class outerClause_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start outerClause
    // T:\\transfer-root\\antlr/Tql.g:188:1: outerClause : ( (LEFT|RIGHT))? OUTER^ ;
    public outerClause_return outerClause() throws RecognitionException {
        outerClause_return retval = new outerClause_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token set28=null;
        Token OUTER29=null;

        Object set28_tree=null;
        Object OUTER29_tree=null;

        try {
            // T:\\transfer-root\\antlr/Tql.g:190:2: ( ( (LEFT|RIGHT))? OUTER^ )
            // T:\\transfer-root\\antlr/Tql.g:190:2: ( (LEFT|RIGHT))? OUTER^
            {
            root_0 = (Object)adaptor.nil();

            // T:\\transfer-root\\antlr/Tql.g:190:2: ( (LEFT|RIGHT))?
            int alt12=2;
            int LA12_0 = input.LA(1);
            if ( ((LA12_0>=LEFT && LA12_0<=RIGHT)) ) {
                alt12=1;
            }
            switch (alt12) {
                case 1 :
                    // T:\\transfer-root\\antlr/Tql.g:190:3: (LEFT|RIGHT)
                    {
                    set28=(Token)input.LT(1);
                    if ( (input.LA(1)>=LEFT && input.LA(1)<=RIGHT) ) {
                        adaptor.addChild(root_0, adaptor.create(set28));
                        input.consume();
                        errorRecovery=false;
                    }
                    else {
                        MismatchedSetException mse =
                            new MismatchedSetException(null,input);
                        recoverFromMismatchedSet(input,mse,FOLLOW_set_in_outerClause268);    throw mse;
                    }


                    }
                    break;

            }

            OUTER29=(Token)input.LT(1);
            match(input,OUTER,FOLLOW_OUTER_in_outerClause276); 
            OUTER29_tree = (Object)adaptor.create(OUTER29);
            root_0 = (Object)adaptor.becomeRoot(OUTER29_tree, root_0);


            }

            retval.stop = input.LT(-1);

                retval.tree = (Object)adaptor.rulePostProcessing(root_0);
                adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end outerClause

    public static class onClause_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start onClause
    // T:\\transfer-root\\antlr/Tql.g:193:1: onClause : ( onComposite | onCondition );
    public onClause_return onClause() throws RecognitionException {
        onClause_return retval = new onClause_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        onComposite_return onComposite30 = null;

        onCondition_return onCondition31 = null;



        try {
            // T:\\transfer-root\\antlr/Tql.g:195:2: ( onComposite | onCondition )
            int alt13=2;
            int LA13_0 = input.LA(1);
            if ( (LA13_0==ON) ) {
                int LA13_1 = input.LA(2);
                if ( (LA13_1==PROPERTY_IDENTIFIER) ) {
                    int LA13_2 = input.LA(3);
                    if ( (LA13_2==OPERATOR||(LA13_2>=IS && LA13_2<=NOT)||LA13_2==IN) ) {
                        alt13=2;
                    }
                    else if ( (LA13_2==EOF||(LA13_2>=JOIN && LA13_2<=OUTER)||(LA13_2>=BOOLEAN_LOGIC && LA13_2<=WHERE)||LA13_2==RIGHT_PAREN||LA13_2==ORDER) ) {
                        alt13=1;
                    }
                    else {
                        NoViableAltException nvae =
                            new NoViableAltException("193:1: onClause : ( onComposite | onCondition );", 13, 2, input);

                        throw nvae;
                    }
                }
                else if ( (LA13_1==LEFT_PAREN) ) {
                    alt13=2;
                }
                else {
                    NoViableAltException nvae =
                        new NoViableAltException("193:1: onClause : ( onComposite | onCondition );", 13, 1, input);

                    throw nvae;
                }
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("193:1: onClause : ( onComposite | onCondition );", 13, 0, input);

                throw nvae;
            }
            switch (alt13) {
                case 1 :
                    // T:\\transfer-root\\antlr/Tql.g:195:2: onComposite
                    {
                    root_0 = (Object)adaptor.nil();

                    pushFollow(FOLLOW_onComposite_in_onClause289);
                    onComposite30=onComposite();
                    _fsp--;

                    adaptor.addChild(root_0, onComposite30.getTree());

                    }
                    break;
                case 2 :
                    // T:\\transfer-root\\antlr/Tql.g:195:16: onCondition
                    {
                    root_0 = (Object)adaptor.nil();

                    pushFollow(FOLLOW_onCondition_in_onClause293);
                    onCondition31=onCondition();
                    _fsp--;

                    adaptor.addChild(root_0, onCondition31.getTree());

                    }
                    break;

            }
            retval.stop = input.LT(-1);

                retval.tree = (Object)adaptor.rulePostProcessing(root_0);
                adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end onClause

    public static class onComposite_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start onComposite
    // T:\\transfer-root\\antlr/Tql.g:198:1: onComposite : ON a= PROPERTY_IDENTIFIER ( BOOLEAN_LOGIC b= PROPERTY_IDENTIFIER )* -> ^( ON_COMPOSITE ON $a ( BOOLEAN_LOGIC $b)* ) ;
    public onComposite_return onComposite() throws RecognitionException {
        onComposite_return retval = new onComposite_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token a=null;
        Token b=null;
        Token ON32=null;
        Token BOOLEAN_LOGIC33=null;
        List list_PROPERTY_IDENTIFIER=new ArrayList();
        List list_BOOLEAN_LOGIC=new ArrayList();
        List list_ON=new ArrayList();
        Object a_tree=null;
        Object b_tree=null;
        Object ON32_tree=null;
        Object BOOLEAN_LOGIC33_tree=null;

        try {
            // T:\\transfer-root\\antlr/Tql.g:200:2: ( ON a= PROPERTY_IDENTIFIER ( BOOLEAN_LOGIC b= PROPERTY_IDENTIFIER )* -> ^( ON_COMPOSITE ON $a ( BOOLEAN_LOGIC $b)* ) )
            // T:\\transfer-root\\antlr/Tql.g:200:2: ON a= PROPERTY_IDENTIFIER ( BOOLEAN_LOGIC b= PROPERTY_IDENTIFIER )*
            {
            ON32=(Token)input.LT(1);
            match(input,ON,FOLLOW_ON_in_onComposite306); 
            list_ON.add(ON32);

            a=(Token)input.LT(1);
            match(input,PROPERTY_IDENTIFIER,FOLLOW_PROPERTY_IDENTIFIER_in_onComposite310); 
            list_PROPERTY_IDENTIFIER.add(a);

            // T:\\transfer-root\\antlr/Tql.g:200:27: ( BOOLEAN_LOGIC b= PROPERTY_IDENTIFIER )*
            loop14:
            do {
                int alt14=2;
                int LA14_0 = input.LA(1);
                if ( (LA14_0==BOOLEAN_LOGIC) ) {
                    alt14=1;
                }


                switch (alt14) {
            	case 1 :
            	    // T:\\transfer-root\\antlr/Tql.g:200:28: BOOLEAN_LOGIC b= PROPERTY_IDENTIFIER
            	    {
            	    BOOLEAN_LOGIC33=(Token)input.LT(1);
            	    match(input,BOOLEAN_LOGIC,FOLLOW_BOOLEAN_LOGIC_in_onComposite313); 
            	    list_BOOLEAN_LOGIC.add(BOOLEAN_LOGIC33);

            	    b=(Token)input.LT(1);
            	    match(input,PROPERTY_IDENTIFIER,FOLLOW_PROPERTY_IDENTIFIER_in_onComposite317); 
            	    list_PROPERTY_IDENTIFIER.add(b);


            	    }
            	    break;

            	default :
            	    break loop14;
                }
            } while (true);


            // AST REWRITE
            int i_0 = 0;
            retval.tree = root_0;
            root_0 = (Object)adaptor.nil();
            // 201:2: -> ^( ON_COMPOSITE ON $a ( BOOLEAN_LOGIC $b)* )
            {
                // T:\\transfer-root\\antlr/Tql.g:201:5: ^( ON_COMPOSITE ON $a ( BOOLEAN_LOGIC $b)* )
                {
                Object root_1 = (Object)adaptor.nil();
                root_1 = (Object)adaptor.becomeRoot(adaptor.create(ON_COMPOSITE, "ON_COMPOSITE"), root_1);

                adaptor.addChild(root_1, (Token)list_ON.get(i_0));
                adaptor.addChild(root_1, a);
                // T:\\transfer-root\\antlr/Tql.g:201:26: ( BOOLEAN_LOGIC $b)*
                {
                int n_1 = list_BOOLEAN_LOGIC == null ? 0 : list_BOOLEAN_LOGIC.size();
                 

                if ( (b==null && n_1>0) || (b!=null && n_1==0) ) throw new RuntimeException("rewrite element b list differs in size from other elements");

                for (int i_1=0; i_1<n_1; i_1++) {
                    adaptor.addChild(root_1, (Token)list_BOOLEAN_LOGIC.get(i_1));
                    adaptor.addChild(root_1, b);

                }
                }

                adaptor.addChild(root_0, root_1);
                }

            }



            }

            retval.stop = input.LT(-1);

                retval.tree = (Object)adaptor.rulePostProcessing(root_0);
                adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end onComposite

    public static class onCondition_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start onCondition
    // T:\\transfer-root\\antlr/Tql.g:204:1: onCondition : ON conditionStatement -> ^( ON_IDENTIFIER ON conditionStatement ) ;
    public onCondition_return onCondition() throws RecognitionException {
        onCondition_return retval = new onCondition_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token ON34=null;
        conditionStatement_return conditionStatement35 = null;

        List list_conditionStatement=new ArrayList();
        List list_ON=new ArrayList();
        Object ON34_tree=null;

        try {
            // T:\\transfer-root\\antlr/Tql.g:206:2: ( ON conditionStatement -> ^( ON_IDENTIFIER ON conditionStatement ) )
            // T:\\transfer-root\\antlr/Tql.g:206:2: ON conditionStatement
            {
            ON34=(Token)input.LT(1);
            match(input,ON,FOLLOW_ON_in_onCondition352); 
            list_ON.add(ON34);

            pushFollow(FOLLOW_conditionStatement_in_onCondition354);
            conditionStatement35=conditionStatement();
            _fsp--;

            list_conditionStatement.add(conditionStatement35.getTree());

            // AST REWRITE
            int i_0 = 0;
            retval.tree = root_0;
            root_0 = (Object)adaptor.nil();
            // 207:2: -> ^( ON_IDENTIFIER ON conditionStatement )
            {
                // T:\\transfer-root\\antlr/Tql.g:207:5: ^( ON_IDENTIFIER ON conditionStatement )
                {
                Object root_1 = (Object)adaptor.nil();
                root_1 = (Object)adaptor.becomeRoot(adaptor.create(ON_IDENTIFIER, "ON_IDENTIFIER"), root_1);

                adaptor.addChild(root_1, (Token)list_ON.get(i_0));
                adaptor.addChild(root_1, list_conditionStatement.get(i_0));

                adaptor.addChild(root_0, root_1);
                }

            }



            }

            retval.stop = input.LT(-1);

                retval.tree = (Object)adaptor.rulePostProcessing(root_0);
                adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end onCondition

    public static class whereStatement_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start whereStatement
    // T:\\transfer-root\\antlr/Tql.g:210:1: whereStatement : WHERE^ conditionStatement ;
    public whereStatement_return whereStatement() throws RecognitionException {
        whereStatement_return retval = new whereStatement_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token WHERE36=null;
        conditionStatement_return conditionStatement37 = null;


        Object WHERE36_tree=null;

        try {
            // T:\\transfer-root\\antlr/Tql.g:212:2: ( WHERE^ conditionStatement )
            // T:\\transfer-root\\antlr/Tql.g:212:2: WHERE^ conditionStatement
            {
            root_0 = (Object)adaptor.nil();

            WHERE36=(Token)input.LT(1);
            match(input,WHERE,FOLLOW_WHERE_in_whereStatement379); 
            WHERE36_tree = (Object)adaptor.create(WHERE36);
            root_0 = (Object)adaptor.becomeRoot(WHERE36_tree, root_0);

            pushFollow(FOLLOW_conditionStatement_in_whereStatement383);
            conditionStatement37=conditionStatement();
            _fsp--;

            adaptor.addChild(root_0, conditionStatement37.getTree());

            }

            retval.stop = input.LT(-1);

                retval.tree = (Object)adaptor.rulePostProcessing(root_0);
                adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end whereStatement

    public static class conditionStatement_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start conditionStatement
    // T:\\transfer-root\\antlr/Tql.g:216:1: conditionStatement : ( condition ) ;
    public conditionStatement_return conditionStatement() throws RecognitionException {
        conditionStatement_return retval = new conditionStatement_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        condition_return condition38 = null;



        try {
            // T:\\transfer-root\\antlr/Tql.g:218:2: ( ( condition ) )
            // T:\\transfer-root\\antlr/Tql.g:218:2: ( condition )
            {
            root_0 = (Object)adaptor.nil();

            // T:\\transfer-root\\antlr/Tql.g:218:2: ( condition )
            // T:\\transfer-root\\antlr/Tql.g:218:4: condition
            {
            pushFollow(FOLLOW_condition_in_conditionStatement398);
            condition38=condition();
            _fsp--;

            adaptor.addChild(root_0, condition38.getTree());

            }


            }

            retval.stop = input.LT(-1);

                retval.tree = (Object)adaptor.rulePostProcessing(root_0);
                adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end conditionStatement

    public static class condition_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start condition
    // T:\\transfer-root\\antlr/Tql.g:221:1: condition : ( conditionBasicClause | conditionParen ) ( BOOLEAN_LOGIC ( conditionBasicClause | conditionParen ) )* ;
    public condition_return condition() throws RecognitionException {
        condition_return retval = new condition_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token BOOLEAN_LOGIC41=null;
        conditionBasicClause_return conditionBasicClause39 = null;

        conditionParen_return conditionParen40 = null;

        conditionBasicClause_return conditionBasicClause42 = null;

        conditionParen_return conditionParen43 = null;


        Object BOOLEAN_LOGIC41_tree=null;

        try {
            // T:\\transfer-root\\antlr/Tql.g:223:2: ( ( conditionBasicClause | conditionParen ) ( BOOLEAN_LOGIC ( conditionBasicClause | conditionParen ) )* )
            // T:\\transfer-root\\antlr/Tql.g:223:2: ( conditionBasicClause | conditionParen ) ( BOOLEAN_LOGIC ( conditionBasicClause | conditionParen ) )*
            {
            root_0 = (Object)adaptor.nil();

            // T:\\transfer-root\\antlr/Tql.g:223:2: ( conditionBasicClause | conditionParen )
            int alt15=2;
            int LA15_0 = input.LA(1);
            if ( (LA15_0==PROPERTY_IDENTIFIER) ) {
                alt15=1;
            }
            else if ( (LA15_0==LEFT_PAREN) ) {
                alt15=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("223:2: ( conditionBasicClause | conditionParen )", 15, 0, input);

                throw nvae;
            }
            switch (alt15) {
                case 1 :
                    // T:\\transfer-root\\antlr/Tql.g:223:4: conditionBasicClause
                    {
                    pushFollow(FOLLOW_conditionBasicClause_in_condition415);
                    conditionBasicClause39=conditionBasicClause();
                    _fsp--;

                    adaptor.addChild(root_0, conditionBasicClause39.getTree());

                    }
                    break;
                case 2 :
                    // T:\\transfer-root\\antlr/Tql.g:223:27: conditionParen
                    {
                    pushFollow(FOLLOW_conditionParen_in_condition419);
                    conditionParen40=conditionParen();
                    _fsp--;

                    adaptor.addChild(root_0, conditionParen40.getTree());

                    }
                    break;

            }

            // T:\\transfer-root\\antlr/Tql.g:223:44: ( BOOLEAN_LOGIC ( conditionBasicClause | conditionParen ) )*
            loop17:
            do {
                int alt17=2;
                int LA17_0 = input.LA(1);
                if ( (LA17_0==BOOLEAN_LOGIC) ) {
                    alt17=1;
                }


                switch (alt17) {
            	case 1 :
            	    // T:\\transfer-root\\antlr/Tql.g:223:46: BOOLEAN_LOGIC ( conditionBasicClause | conditionParen )
            	    {
            	    BOOLEAN_LOGIC41=(Token)input.LT(1);
            	    match(input,BOOLEAN_LOGIC,FOLLOW_BOOLEAN_LOGIC_in_condition425); 
            	    BOOLEAN_LOGIC41_tree = (Object)adaptor.create(BOOLEAN_LOGIC41);
            	    adaptor.addChild(root_0, BOOLEAN_LOGIC41_tree);

            	    // T:\\transfer-root\\antlr/Tql.g:223:60: ( conditionBasicClause | conditionParen )
            	    int alt16=2;
            	    int LA16_0 = input.LA(1);
            	    if ( (LA16_0==PROPERTY_IDENTIFIER) ) {
            	        alt16=1;
            	    }
            	    else if ( (LA16_0==LEFT_PAREN) ) {
            	        alt16=2;
            	    }
            	    else {
            	        NoViableAltException nvae =
            	            new NoViableAltException("223:60: ( conditionBasicClause | conditionParen )", 16, 0, input);

            	        throw nvae;
            	    }
            	    switch (alt16) {
            	        case 1 :
            	            // T:\\transfer-root\\antlr/Tql.g:223:62: conditionBasicClause
            	            {
            	            pushFollow(FOLLOW_conditionBasicClause_in_condition429);
            	            conditionBasicClause42=conditionBasicClause();
            	            _fsp--;

            	            adaptor.addChild(root_0, conditionBasicClause42.getTree());

            	            }
            	            break;
            	        case 2 :
            	            // T:\\transfer-root\\antlr/Tql.g:223:85: conditionParen
            	            {
            	            pushFollow(FOLLOW_conditionParen_in_condition433);
            	            conditionParen43=conditionParen();
            	            _fsp--;

            	            adaptor.addChild(root_0, conditionParen43.getTree());

            	            }
            	            break;

            	    }


            	    }
            	    break;

            	default :
            	    break loop17;
                }
            } while (true);


            }

            retval.stop = input.LT(-1);

                retval.tree = (Object)adaptor.rulePostProcessing(root_0);
                adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end condition

    public static class conditionParen_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start conditionParen
    // T:\\transfer-root\\antlr/Tql.g:226:1: conditionParen : LEFT_PAREN conditionStatement RIGHT_PAREN ;
    public conditionParen_return conditionParen() throws RecognitionException {
        conditionParen_return retval = new conditionParen_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token LEFT_PAREN44=null;
        Token RIGHT_PAREN46=null;
        conditionStatement_return conditionStatement45 = null;


        Object LEFT_PAREN44_tree=null;
        Object RIGHT_PAREN46_tree=null;

        try {
            // T:\\transfer-root\\antlr/Tql.g:228:2: ( LEFT_PAREN conditionStatement RIGHT_PAREN )
            // T:\\transfer-root\\antlr/Tql.g:228:2: LEFT_PAREN conditionStatement RIGHT_PAREN
            {
            root_0 = (Object)adaptor.nil();

            LEFT_PAREN44=(Token)input.LT(1);
            match(input,LEFT_PAREN,FOLLOW_LEFT_PAREN_in_conditionParen450); 
            LEFT_PAREN44_tree = (Object)adaptor.create(LEFT_PAREN44);
            adaptor.addChild(root_0, LEFT_PAREN44_tree);

            pushFollow(FOLLOW_conditionStatement_in_conditionParen452);
            conditionStatement45=conditionStatement();
            _fsp--;

            adaptor.addChild(root_0, conditionStatement45.getTree());
            RIGHT_PAREN46=(Token)input.LT(1);
            match(input,RIGHT_PAREN,FOLLOW_RIGHT_PAREN_in_conditionParen454); 
            RIGHT_PAREN46_tree = (Object)adaptor.create(RIGHT_PAREN46);
            adaptor.addChild(root_0, RIGHT_PAREN46_tree);


            }

            retval.stop = input.LT(-1);

                retval.tree = (Object)adaptor.rulePostProcessing(root_0);
                adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end conditionParen

    public static class conditionBasicClause_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start conditionBasicClause
    // T:\\transfer-root\\antlr/Tql.g:231:1: conditionBasicClause : PROPERTY_IDENTIFIER ( operatorClause | isNullClause | inClause ) ;
    public conditionBasicClause_return conditionBasicClause() throws RecognitionException {
        conditionBasicClause_return retval = new conditionBasicClause_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token PROPERTY_IDENTIFIER47=null;
        operatorClause_return operatorClause48 = null;

        isNullClause_return isNullClause49 = null;

        inClause_return inClause50 = null;


        Object PROPERTY_IDENTIFIER47_tree=null;

        try {
            // T:\\transfer-root\\antlr/Tql.g:233:2: ( PROPERTY_IDENTIFIER ( operatorClause | isNullClause | inClause ) )
            // T:\\transfer-root\\antlr/Tql.g:233:2: PROPERTY_IDENTIFIER ( operatorClause | isNullClause | inClause )
            {
            root_0 = (Object)adaptor.nil();

            PROPERTY_IDENTIFIER47=(Token)input.LT(1);
            match(input,PROPERTY_IDENTIFIER,FOLLOW_PROPERTY_IDENTIFIER_in_conditionBasicClause468); 
            PROPERTY_IDENTIFIER47_tree = (Object)adaptor.create(PROPERTY_IDENTIFIER47);
            adaptor.addChild(root_0, PROPERTY_IDENTIFIER47_tree);

            // T:\\transfer-root\\antlr/Tql.g:233:22: ( operatorClause | isNullClause | inClause )
            int alt18=3;
            switch ( input.LA(1) ) {
            case OPERATOR:
                alt18=1;
                break;
            case IS:
                alt18=2;
                break;
            case NOT:
            case IN:
                alt18=3;
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("233:22: ( operatorClause | isNullClause | inClause )", 18, 0, input);

                throw nvae;
            }

            switch (alt18) {
                case 1 :
                    // T:\\transfer-root\\antlr/Tql.g:233:24: operatorClause
                    {
                    pushFollow(FOLLOW_operatorClause_in_conditionBasicClause472);
                    operatorClause48=operatorClause();
                    _fsp--;

                    adaptor.addChild(root_0, operatorClause48.getTree());

                    }
                    break;
                case 2 :
                    // T:\\transfer-root\\antlr/Tql.g:233:41: isNullClause
                    {
                    pushFollow(FOLLOW_isNullClause_in_conditionBasicClause476);
                    isNullClause49=isNullClause();
                    _fsp--;

                    adaptor.addChild(root_0, isNullClause49.getTree());

                    }
                    break;
                case 3 :
                    // T:\\transfer-root\\antlr/Tql.g:233:56: inClause
                    {
                    pushFollow(FOLLOW_inClause_in_conditionBasicClause480);
                    inClause50=inClause();
                    _fsp--;

                    adaptor.addChild(root_0, inClause50.getTree());

                    }
                    break;

            }


            }

            retval.stop = input.LT(-1);

                retval.tree = (Object)adaptor.rulePostProcessing(root_0);
                adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end conditionBasicClause

    public static class operatorClause_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start operatorClause
    // T:\\transfer-root\\antlr/Tql.g:236:1: operatorClause : OPERATOR (MAPPED_PARAM|PROPERTY_IDENTIFIER);
    public operatorClause_return operatorClause() throws RecognitionException {
        operatorClause_return retval = new operatorClause_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token OPERATOR51=null;
        Token set52=null;

        Object OPERATOR51_tree=null;
        Object set52_tree=null;

        try {
            // T:\\transfer-root\\antlr/Tql.g:238:3: ( OPERATOR (MAPPED_PARAM|PROPERTY_IDENTIFIER))
            // T:\\transfer-root\\antlr/Tql.g:238:3: OPERATOR (MAPPED_PARAM|PROPERTY_IDENTIFIER)
            {
            root_0 = (Object)adaptor.nil();

            OPERATOR51=(Token)input.LT(1);
            match(input,OPERATOR,FOLLOW_OPERATOR_in_operatorClause496); 
            OPERATOR51_tree = (Object)adaptor.create(OPERATOR51);
            adaptor.addChild(root_0, OPERATOR51_tree);

            set52=(Token)input.LT(1);
            if ( input.LA(1)==PROPERTY_IDENTIFIER||input.LA(1)==MAPPED_PARAM ) {
                adaptor.addChild(root_0, adaptor.create(set52));
                input.consume();
                errorRecovery=false;
            }
            else {
                MismatchedSetException mse =
                    new MismatchedSetException(null,input);
                recoverFromMismatchedSet(input,mse,FOLLOW_set_in_operatorClause499);    throw mse;
            }


            }

            retval.stop = input.LT(-1);

                retval.tree = (Object)adaptor.rulePostProcessing(root_0);
                adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end operatorClause

    public static class isNullClause_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start isNullClause
    // T:\\transfer-root\\antlr/Tql.g:241:1: isNullClause : IS ( NOT )? NULL ;
    public isNullClause_return isNullClause() throws RecognitionException {
        isNullClause_return retval = new isNullClause_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token IS53=null;
        Token NOT54=null;
        Token NULL55=null;

        Object IS53_tree=null;
        Object NOT54_tree=null;
        Object NULL55_tree=null;

        try {
            // T:\\transfer-root\\antlr/Tql.g:243:2: ( IS ( NOT )? NULL )
            // T:\\transfer-root\\antlr/Tql.g:243:2: IS ( NOT )? NULL
            {
            root_0 = (Object)adaptor.nil();

            IS53=(Token)input.LT(1);
            match(input,IS,FOLLOW_IS_in_isNullClause517); 
            IS53_tree = (Object)adaptor.create(IS53);
            adaptor.addChild(root_0, IS53_tree);

            // T:\\transfer-root\\antlr/Tql.g:243:5: ( NOT )?
            int alt19=2;
            int LA19_0 = input.LA(1);
            if ( (LA19_0==NOT) ) {
                alt19=1;
            }
            switch (alt19) {
                case 1 :
                    // T:\\transfer-root\\antlr/Tql.g:243:5: NOT
                    {
                    NOT54=(Token)input.LT(1);
                    match(input,NOT,FOLLOW_NOT_in_isNullClause519); 
                    NOT54_tree = (Object)adaptor.create(NOT54);
                    adaptor.addChild(root_0, NOT54_tree);


                    }
                    break;

            }

            NULL55=(Token)input.LT(1);
            match(input,NULL,FOLLOW_NULL_in_isNullClause522); 
            NULL55_tree = (Object)adaptor.create(NULL55);
            adaptor.addChild(root_0, NULL55_tree);


            }

            retval.stop = input.LT(-1);

                retval.tree = (Object)adaptor.rulePostProcessing(root_0);
                adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end isNullClause

    public static class inClause_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start inClause
    // T:\\transfer-root\\antlr/Tql.g:246:1: inClause : ( NOT )? IN LEFT_PAREN ( MAPPED_PARAM | selectExpression ) RIGHT_PAREN ;
    public inClause_return inClause() throws RecognitionException {
        inClause_return retval = new inClause_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token NOT56=null;
        Token IN57=null;
        Token LEFT_PAREN58=null;
        Token MAPPED_PARAM59=null;
        Token RIGHT_PAREN61=null;
        selectExpression_return selectExpression60 = null;


        Object NOT56_tree=null;
        Object IN57_tree=null;
        Object LEFT_PAREN58_tree=null;
        Object MAPPED_PARAM59_tree=null;
        Object RIGHT_PAREN61_tree=null;

        try {
            // T:\\transfer-root\\antlr/Tql.g:248:2: ( ( NOT )? IN LEFT_PAREN ( MAPPED_PARAM | selectExpression ) RIGHT_PAREN )
            // T:\\transfer-root\\antlr/Tql.g:248:2: ( NOT )? IN LEFT_PAREN ( MAPPED_PARAM | selectExpression ) RIGHT_PAREN
            {
            root_0 = (Object)adaptor.nil();

            // T:\\transfer-root\\antlr/Tql.g:248:2: ( NOT )?
            int alt20=2;
            int LA20_0 = input.LA(1);
            if ( (LA20_0==NOT) ) {
                alt20=1;
            }
            switch (alt20) {
                case 1 :
                    // T:\\transfer-root\\antlr/Tql.g:248:2: NOT
                    {
                    NOT56=(Token)input.LT(1);
                    match(input,NOT,FOLLOW_NOT_in_inClause535); 
                    NOT56_tree = (Object)adaptor.create(NOT56);
                    adaptor.addChild(root_0, NOT56_tree);


                    }
                    break;

            }

            IN57=(Token)input.LT(1);
            match(input,IN,FOLLOW_IN_in_inClause538); 
            IN57_tree = (Object)adaptor.create(IN57);
            adaptor.addChild(root_0, IN57_tree);

            LEFT_PAREN58=(Token)input.LT(1);
            match(input,LEFT_PAREN,FOLLOW_LEFT_PAREN_in_inClause540); 
            LEFT_PAREN58_tree = (Object)adaptor.create(LEFT_PAREN58);
            adaptor.addChild(root_0, LEFT_PAREN58_tree);

            // T:\\transfer-root\\antlr/Tql.g:248:21: ( MAPPED_PARAM | selectExpression )
            int alt21=2;
            int LA21_0 = input.LA(1);
            if ( (LA21_0==MAPPED_PARAM) ) {
                alt21=1;
            }
            else if ( (LA21_0==SELECT) ) {
                alt21=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("248:21: ( MAPPED_PARAM | selectExpression )", 21, 0, input);

                throw nvae;
            }
            switch (alt21) {
                case 1 :
                    // T:\\transfer-root\\antlr/Tql.g:248:23: MAPPED_PARAM
                    {
                    MAPPED_PARAM59=(Token)input.LT(1);
                    match(input,MAPPED_PARAM,FOLLOW_MAPPED_PARAM_in_inClause544); 
                    MAPPED_PARAM59_tree = (Object)adaptor.create(MAPPED_PARAM59);
                    adaptor.addChild(root_0, MAPPED_PARAM59_tree);


                    }
                    break;
                case 2 :
                    // T:\\transfer-root\\antlr/Tql.g:248:38: selectExpression
                    {
                    pushFollow(FOLLOW_selectExpression_in_inClause548);
                    selectExpression60=selectExpression();
                    _fsp--;

                    adaptor.addChild(root_0, selectExpression60.getTree());

                    }
                    break;

            }

            RIGHT_PAREN61=(Token)input.LT(1);
            match(input,RIGHT_PAREN,FOLLOW_RIGHT_PAREN_in_inClause552); 
            RIGHT_PAREN61_tree = (Object)adaptor.create(RIGHT_PAREN61);
            adaptor.addChild(root_0, RIGHT_PAREN61_tree);


            }

            retval.stop = input.LT(-1);

                retval.tree = (Object)adaptor.rulePostProcessing(root_0);
                adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end inClause

    public static class orderByStatement_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start orderByStatement
    // T:\\transfer-root\\antlr/Tql.g:251:1: orderByStatement : ORDER^ BY orderByClause ( COMMA orderByClause )* ;
    public orderByStatement_return orderByStatement() throws RecognitionException {
        orderByStatement_return retval = new orderByStatement_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token ORDER62=null;
        Token BY63=null;
        Token COMMA65=null;
        orderByClause_return orderByClause64 = null;

        orderByClause_return orderByClause66 = null;


        Object ORDER62_tree=null;
        Object BY63_tree=null;
        Object COMMA65_tree=null;

        try {
            // T:\\transfer-root\\antlr/Tql.g:253:2: ( ORDER^ BY orderByClause ( COMMA orderByClause )* )
            // T:\\transfer-root\\antlr/Tql.g:253:2: ORDER^ BY orderByClause ( COMMA orderByClause )*
            {
            root_0 = (Object)adaptor.nil();

            ORDER62=(Token)input.LT(1);
            match(input,ORDER,FOLLOW_ORDER_in_orderByStatement565); 
            ORDER62_tree = (Object)adaptor.create(ORDER62);
            root_0 = (Object)adaptor.becomeRoot(ORDER62_tree, root_0);

            BY63=(Token)input.LT(1);
            match(input,BY,FOLLOW_BY_in_orderByStatement568); 
            BY63_tree = (Object)adaptor.create(BY63);
            adaptor.addChild(root_0, BY63_tree);

            pushFollow(FOLLOW_orderByClause_in_orderByStatement570);
            orderByClause64=orderByClause();
            _fsp--;

            adaptor.addChild(root_0, orderByClause64.getTree());
            // T:\\transfer-root\\antlr/Tql.g:253:26: ( COMMA orderByClause )*
            loop22:
            do {
                int alt22=2;
                int LA22_0 = input.LA(1);
                if ( (LA22_0==COMMA) ) {
                    alt22=1;
                }


                switch (alt22) {
            	case 1 :
            	    // T:\\transfer-root\\antlr/Tql.g:253:27: COMMA orderByClause
            	    {
            	    COMMA65=(Token)input.LT(1);
            	    match(input,COMMA,FOLLOW_COMMA_in_orderByStatement573); 
            	    COMMA65_tree = (Object)adaptor.create(COMMA65);
            	    adaptor.addChild(root_0, COMMA65_tree);

            	    pushFollow(FOLLOW_orderByClause_in_orderByStatement575);
            	    orderByClause66=orderByClause();
            	    _fsp--;

            	    adaptor.addChild(root_0, orderByClause66.getTree());

            	    }
            	    break;

            	default :
            	    break loop22;
                }
            } while (true);


            }

            retval.stop = input.LT(-1);

                retval.tree = (Object)adaptor.rulePostProcessing(root_0);
                adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end orderByStatement

    public static class orderByClause_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start orderByClause
    // T:\\transfer-root\\antlr/Tql.g:256:1: orderByClause : PROPERTY_IDENTIFIER ( ASC_DESC )? ;
    public orderByClause_return orderByClause() throws RecognitionException {
        orderByClause_return retval = new orderByClause_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token PROPERTY_IDENTIFIER67=null;
        Token ASC_DESC68=null;

        Object PROPERTY_IDENTIFIER67_tree=null;
        Object ASC_DESC68_tree=null;

        try {
            // T:\\transfer-root\\antlr/Tql.g:258:2: ( PROPERTY_IDENTIFIER ( ASC_DESC )? )
            // T:\\transfer-root\\antlr/Tql.g:258:2: PROPERTY_IDENTIFIER ( ASC_DESC )?
            {
            root_0 = (Object)adaptor.nil();

            PROPERTY_IDENTIFIER67=(Token)input.LT(1);
            match(input,PROPERTY_IDENTIFIER,FOLLOW_PROPERTY_IDENTIFIER_in_orderByClause590); 
            PROPERTY_IDENTIFIER67_tree = (Object)adaptor.create(PROPERTY_IDENTIFIER67);
            adaptor.addChild(root_0, PROPERTY_IDENTIFIER67_tree);

            // T:\\transfer-root\\antlr/Tql.g:258:22: ( ASC_DESC )?
            int alt23=2;
            int LA23_0 = input.LA(1);
            if ( (LA23_0==ASC_DESC) ) {
                alt23=1;
            }
            switch (alt23) {
                case 1 :
                    // T:\\transfer-root\\antlr/Tql.g:258:23: ASC_DESC
                    {
                    ASC_DESC68=(Token)input.LT(1);
                    match(input,ASC_DESC,FOLLOW_ASC_DESC_in_orderByClause593); 
                    ASC_DESC68_tree = (Object)adaptor.create(ASC_DESC68);
                    adaptor.addChild(root_0, ASC_DESC68_tree);


                    }
                    break;

            }


            }

            retval.stop = input.LT(-1);

                retval.tree = (Object)adaptor.rulePostProcessing(root_0);
                adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end orderByClause


 

    public static final BitSet FOLLOW_fromExpression_in_selectStatement78 = new BitSet(new long[]{0x0000000020000002L});
    public static final BitSet FOLLOW_selectExpression_in_selectStatement83 = new BitSet(new long[]{0x0000000020000002L});
    public static final BitSet FOLLOW_orderByStatement_in_selectStatement89 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_fromStatement_in_fromExpression103 = new BitSet(new long[]{0x0000000000100002L});
    public static final BitSet FOLLOW_whereStatement_in_fromExpression107 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_selectHeader_in_selectExpression121 = new BitSet(new long[]{0x0000000000001000L});
    public static final BitSet FOLLOW_fromStatement_in_selectExpression125 = new BitSet(new long[]{0x0000000000100002L});
    public static final BitSet FOLLOW_whereStatement_in_selectExpression128 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_SELECT_in_selectHeader142 = new BitSet(new long[]{0x0000000000000300L});
    public static final BitSet FOLLOW_propertyStatement_in_selectHeader145 = new BitSet(new long[]{0x0000000000000082L});
    public static final BitSet FOLLOW_COMMA_in_selectHeader148 = new BitSet(new long[]{0x0000000000000300L});
    public static final BitSet FOLLOW_propertyStatement_in_selectHeader150 = new BitSet(new long[]{0x0000000000000082L});
    public static final BitSet FOLLOW_propertyClause_in_propertyStatement164 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ASTERISK_in_propertyStatement168 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_PROPERTY_IDENTIFIER_in_propertyClause181 = new BitSet(new long[]{0x0000000000000402L});
    public static final BitSet FOLLOW_AS_in_propertyClause185 = new BitSet(new long[]{0x0000000000000800L});
    public static final BitSet FOLLOW_ALIAS_in_propertyClause187 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_FROM_in_fromStatement201 = new BitSet(new long[]{0x0000000000002000L});
    public static final BitSet FOLLOW_classClause_in_fromStatement204 = new BitSet(new long[]{0x000000000003C002L});
    public static final BitSet FOLLOW_joinClause_in_fromStatement207 = new BitSet(new long[]{0x000000000003C002L});
    public static final BitSet FOLLOW_CLASS_IDENTIFIER_in_classClause222 = new BitSet(new long[]{0x0000000000000402L});
    public static final BitSet FOLLOW_AS_in_classClause226 = new BitSet(new long[]{0x0000000000000800L});
    public static final BitSet FOLLOW_ALIAS_in_classClause228 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_outerClause_in_joinClause243 = new BitSet(new long[]{0x0000000000004000L});
    public static final BitSet FOLLOW_JOIN_in_joinClause247 = new BitSet(new long[]{0x0000000000002000L});
    public static final BitSet FOLLOW_classClause_in_joinClause250 = new BitSet(new long[]{0x0000000000040002L});
    public static final BitSet FOLLOW_onClause_in_joinClause253 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_set_in_outerClause268 = new BitSet(new long[]{0x0000000000020000L});
    public static final BitSet FOLLOW_OUTER_in_outerClause276 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_onComposite_in_onClause289 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_onCondition_in_onClause293 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ON_in_onComposite306 = new BitSet(new long[]{0x0000000000000200L});
    public static final BitSet FOLLOW_PROPERTY_IDENTIFIER_in_onComposite310 = new BitSet(new long[]{0x0000000000080002L});
    public static final BitSet FOLLOW_BOOLEAN_LOGIC_in_onComposite313 = new BitSet(new long[]{0x0000000000000200L});
    public static final BitSet FOLLOW_PROPERTY_IDENTIFIER_in_onComposite317 = new BitSet(new long[]{0x0000000000080002L});
    public static final BitSet FOLLOW_ON_in_onCondition352 = new BitSet(new long[]{0x0000000000200200L});
    public static final BitSet FOLLOW_conditionStatement_in_onCondition354 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_WHERE_in_whereStatement379 = new BitSet(new long[]{0x0000000000200200L});
    public static final BitSet FOLLOW_conditionStatement_in_whereStatement383 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_condition_in_conditionStatement398 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_conditionBasicClause_in_condition415 = new BitSet(new long[]{0x0000000000080002L});
    public static final BitSet FOLLOW_conditionParen_in_condition419 = new BitSet(new long[]{0x0000000000080002L});
    public static final BitSet FOLLOW_BOOLEAN_LOGIC_in_condition425 = new BitSet(new long[]{0x0000000000200200L});
    public static final BitSet FOLLOW_conditionBasicClause_in_condition429 = new BitSet(new long[]{0x0000000000080002L});
    public static final BitSet FOLLOW_conditionParen_in_condition433 = new BitSet(new long[]{0x0000000000080002L});
    public static final BitSet FOLLOW_LEFT_PAREN_in_conditionParen450 = new BitSet(new long[]{0x0000000000200200L});
    public static final BitSet FOLLOW_conditionStatement_in_conditionParen452 = new BitSet(new long[]{0x0000000000400000L});
    public static final BitSet FOLLOW_RIGHT_PAREN_in_conditionParen454 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_PROPERTY_IDENTIFIER_in_conditionBasicClause468 = new BitSet(new long[]{0x0000000016800000L});
    public static final BitSet FOLLOW_operatorClause_in_conditionBasicClause472 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_isNullClause_in_conditionBasicClause476 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_inClause_in_conditionBasicClause480 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_OPERATOR_in_operatorClause496 = new BitSet(new long[]{0x0000000001000200L});
    public static final BitSet FOLLOW_set_in_operatorClause499 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_IS_in_isNullClause517 = new BitSet(new long[]{0x000000000C000000L});
    public static final BitSet FOLLOW_NOT_in_isNullClause519 = new BitSet(new long[]{0x0000000008000000L});
    public static final BitSet FOLLOW_NULL_in_isNullClause522 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_NOT_in_inClause535 = new BitSet(new long[]{0x0000000010000000L});
    public static final BitSet FOLLOW_IN_in_inClause538 = new BitSet(new long[]{0x0000000000200000L});
    public static final BitSet FOLLOW_LEFT_PAREN_in_inClause540 = new BitSet(new long[]{0x0000000001000040L});
    public static final BitSet FOLLOW_MAPPED_PARAM_in_inClause544 = new BitSet(new long[]{0x0000000000400000L});
    public static final BitSet FOLLOW_selectExpression_in_inClause548 = new BitSet(new long[]{0x0000000000400000L});
    public static final BitSet FOLLOW_RIGHT_PAREN_in_inClause552 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ORDER_in_orderByStatement565 = new BitSet(new long[]{0x0000000040000000L});
    public static final BitSet FOLLOW_BY_in_orderByStatement568 = new BitSet(new long[]{0x0000000000000200L});
    public static final BitSet FOLLOW_orderByClause_in_orderByStatement570 = new BitSet(new long[]{0x0000000000000082L});
    public static final BitSet FOLLOW_COMMA_in_orderByStatement573 = new BitSet(new long[]{0x0000000000000200L});
    public static final BitSet FOLLOW_orderByClause_in_orderByStatement575 = new BitSet(new long[]{0x0000000000000082L});
    public static final BitSet FOLLOW_PROPERTY_IDENTIFIER_in_orderByClause590 = new BitSet(new long[]{0x0000000080000002L});
    public static final BitSet FOLLOW_ASC_DESC_in_orderByClause593 = new BitSet(new long[]{0x0000000000000002L});

}