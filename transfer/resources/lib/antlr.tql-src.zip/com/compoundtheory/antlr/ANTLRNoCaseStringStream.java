package com.compoundtheory.antlr;

import org.antlr.runtime.*;

/**
 * Case insensitive string stream for antler
 * 
 * @author mark
 *
 */
public class ANTLRNoCaseStringStream extends ANTLRStringStream
{
	public ANTLRNoCaseStringStream(String input)
	{
		super(input);
	}
	
	public int LA(int i)
	{
		int returnChar = super.LA(i);
		if(returnChar == CharStream.EOF)
		{
			return returnChar; 
		}
		else if(returnChar == 0)
		{
			return returnChar;
		}
		
		return Character.toLowerCase((char)returnChar);
	}
}
