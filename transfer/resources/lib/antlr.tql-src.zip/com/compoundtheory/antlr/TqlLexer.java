// $ANTLR 3.0b7 T:\\transfer-root\\antlr/Tql.g 2007-03-15 16:30:49

package com.compoundtheory.antlr;

/**
* Transfer Query Language Lexer
*
* @author Mark Mandel
*/


import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

public class TqlLexer extends Lexer {
    public static final int COMMA=7;
    public static final int LEFT_PAREN=21;
    public static final int LETTER=32;
    public static final int AS=10;
    public static final int WS=35;
    public static final int IS=25;
    public static final int CLASS_IDENTIFIER=13;
    public static final int PROPERTY_IDENTIFIER=9;
    public static final int ASC_DESC=31;
    public static final int ALIAS=11;
    public static final int MAPPED_PARAM=24;
    public static final int ON=18;
    public static final int IN=28;
    public static final int ORDER=29;
    public static final int BY=30;
    public static final int RIGHT=16;
    public static final int ON_COMPOSITE=4;
    public static final int BOOLEAN_LOGIC=19;
    public static final int EOF=-1;
    public static final int SELECT=6;
    public static final int NULL=27;
    public static final int ASTERISK=8;
    public static final int Tokens=36;
    public static final int LEFT=15;
    public static final int DIGIT=33;
    public static final int OPERATOR=23;
    public static final int IDENTIFIER=34;
    public static final int ON_IDENTIFIER=5;
    public static final int JOIN=14;
    public static final int RIGHT_PAREN=22;
    public static final int NOT=26;
    public static final int OUTER=17;
    public static final int FROM=12;
    public static final int WHERE=20;
    
    	private static final int STRING_MODE = 1;
    	private static final int PROPERTY_IDENTIFIER_MODE = 2;
    	private static final int CLASS_IDENTIFIER_MODE = 3;
    	private static final int ALIAS_MODE = 4;
    	
    	private int currentMode = STRING_MODE;
    	private int pastMode;
    
    	private RecognitionException recognitionException;
    	private String errorMessage;
    	
    	private void setMode(int mode)
    	{
    		pastMode = currentMode;
    		currentMode = mode;
    	}
    
    	public void displayRecognitionError(String[] tokenNames, RecognitionException e)
    	{
    		if(!hasError())
    		{
    			setRecognitionException(e);
    			setErrorMessage(getErrorMessage(e, tokenNames));		
    		}
    	}
    	
    	public RecognitionException getRecognitionException()
    	{
    		return recognitionException;
    	}
    	
    	private void setRecognitionException(RecognitionException e)
    	{
    		recognitionException = e;
    	}
    	
    	public boolean hasError()
    	{
    		return (getRecognitionException() != null);
    	}
    	
    	public String getErrorMessage()
    	{
    		return errorMessage;
    	}
    	
    	private void setErrorMessage(String error)
    	{
    		errorMessage = error;
    	}

    public TqlLexer() {;} 
    public TqlLexer(CharStream input) {
        super(input);
    }
    public String getGrammarFileName() { return "T:\\transfer-root\\antlr/Tql.g"; }

    // $ANTLR start SELECT
    public void mSELECT() throws RecognitionException {
        try {
            ruleNestingLevel++;
            int _type = SELECT;
            int _start = getCharIndex();
            int _line = getLine();
            int _charPosition = getCharPositionInLine();
            int _channel = Token.DEFAULT_CHANNEL;
            // T:\\transfer-root\\antlr/Tql.g:265:2: ({...}? => 'select' )
            // T:\\transfer-root\\antlr/Tql.g:265:2: {...}? => 'select'
            {
            if ( !( currentMode == STRING_MODE ) ) {
                throw new FailedPredicateException(input, "SELECT", " currentMode == STRING_MODE ");
            }
            match("select"); 

             setMode(PROPERTY_IDENTIFIER_MODE); 

            }



                    if ( token==null && ruleNestingLevel==1 ) {
                        emit(_type,_line,_charPosition,_channel,_start,getCharIndex()-1);
                    }

                    
        }
        finally {
            ruleNestingLevel--;
        }
    }
    // $ANTLR end SELECT

    // $ANTLR start FROM
    public void mFROM() throws RecognitionException {
        try {
            ruleNestingLevel++;
            int _type = FROM;
            int _start = getCharIndex();
            int _line = getLine();
            int _charPosition = getCharPositionInLine();
            int _channel = Token.DEFAULT_CHANNEL;
            // T:\\transfer-root\\antlr/Tql.g:270:2: ({...}? => 'from' )
            // T:\\transfer-root\\antlr/Tql.g:270:2: {...}? => 'from'
            {
            if ( !( currentMode == STRING_MODE ) ) {
                throw new FailedPredicateException(input, "FROM", " currentMode == STRING_MODE ");
            }
            match("from"); 

             setMode(CLASS_IDENTIFIER_MODE); 

            }



                    if ( token==null && ruleNestingLevel==1 ) {
                        emit(_type,_line,_charPosition,_channel,_start,getCharIndex()-1);
                    }

                    
        }
        finally {
            ruleNestingLevel--;
        }
    }
    // $ANTLR end FROM

    // $ANTLR start WHERE
    public void mWHERE() throws RecognitionException {
        try {
            ruleNestingLevel++;
            int _type = WHERE;
            int _start = getCharIndex();
            int _line = getLine();
            int _charPosition = getCharPositionInLine();
            int _channel = Token.DEFAULT_CHANNEL;
            // T:\\transfer-root\\antlr/Tql.g:275:2: ({...}? => 'where' )
            // T:\\transfer-root\\antlr/Tql.g:275:2: {...}? => 'where'
            {
            if ( !( currentMode == STRING_MODE ) ) {
                throw new FailedPredicateException(input, "WHERE", " currentMode == STRING_MODE ");
            }
            match("where"); 

             setMode(PROPERTY_IDENTIFIER_MODE); 

            }



                    if ( token==null && ruleNestingLevel==1 ) {
                        emit(_type,_line,_charPosition,_channel,_start,getCharIndex()-1);
                    }

                    
        }
        finally {
            ruleNestingLevel--;
        }
    }
    // $ANTLR end WHERE

    // $ANTLR start COMMA
    public void mCOMMA() throws RecognitionException {
        try {
            ruleNestingLevel++;
            int _type = COMMA;
            int _start = getCharIndex();
            int _line = getLine();
            int _charPosition = getCharPositionInLine();
            int _channel = Token.DEFAULT_CHANNEL;
            // T:\\transfer-root\\antlr/Tql.g:280:2: ( ',' )
            // T:\\transfer-root\\antlr/Tql.g:280:2: ','
            {
            match(','); 
             setMode(pastMode); 

            }



                    if ( token==null && ruleNestingLevel==1 ) {
                        emit(_type,_line,_charPosition,_channel,_start,getCharIndex()-1);
                    }

                    
        }
        finally {
            ruleNestingLevel--;
        }
    }
    // $ANTLR end COMMA

    // $ANTLR start AS
    public void mAS() throws RecognitionException {
        try {
            ruleNestingLevel++;
            int _type = AS;
            int _start = getCharIndex();
            int _line = getLine();
            int _charPosition = getCharPositionInLine();
            int _channel = Token.DEFAULT_CHANNEL;
            // T:\\transfer-root\\antlr/Tql.g:284:2: ({...}? => 'as' )
            // T:\\transfer-root\\antlr/Tql.g:284:2: {...}? => 'as'
            {
            if ( !( currentMode == STRING_MODE ) ) {
                throw new FailedPredicateException(input, "AS", " currentMode == STRING_MODE ");
            }
            match("as"); 

             currentMode = ALIAS_MODE; 

            }



                    if ( token==null && ruleNestingLevel==1 ) {
                        emit(_type,_line,_charPosition,_channel,_start,getCharIndex()-1);
                    }

                    
        }
        finally {
            ruleNestingLevel--;
        }
    }
    // $ANTLR end AS

    // $ANTLR start ALIAS
    public void mALIAS() throws RecognitionException {
        try {
            ruleNestingLevel++;
            int _type = ALIAS;
            int _start = getCharIndex();
            int _line = getLine();
            int _charPosition = getCharPositionInLine();
            int _channel = Token.DEFAULT_CHANNEL;
            // T:\\transfer-root\\antlr/Tql.g:290:2: ({...}? => LETTER ( LETTER | DIGIT | '_' )* )
            // T:\\transfer-root\\antlr/Tql.g:290:2: {...}? => LETTER ( LETTER | DIGIT | '_' )*
            {
            if ( !( currentMode == ALIAS_MODE ) ) {
                throw new FailedPredicateException(input, "ALIAS", " currentMode == ALIAS_MODE ");
            }
            mLETTER(); 
            // T:\\transfer-root\\antlr/Tql.g:291:8: ( LETTER | DIGIT | '_' )*
            loop1:
            do {
                int alt1=4;
                switch ( input.LA(1) ) {
                case 'a':
                case 'b':
                case 'c':
                case 'd':
                case 'e':
                case 'f':
                case 'g':
                case 'h':
                case 'i':
                case 'j':
                case 'k':
                case 'l':
                case 'm':
                case 'n':
                case 'o':
                case 'p':
                case 'q':
                case 'r':
                case 's':
                case 't':
                case 'u':
                case 'v':
                case 'w':
                case 'x':
                case 'y':
                case 'z':
                    alt1=1;
                    break;
                case '0':
                case '1':
                case '2':
                case '3':
                case '4':
                case '5':
                case '6':
                case '7':
                case '8':
                case '9':
                    alt1=2;
                    break;
                case '_':
                    alt1=3;
                    break;

                }

                switch (alt1) {
            	case 1 :
            	    // T:\\transfer-root\\antlr/Tql.g:291:9: LETTER
            	    {
            	    mLETTER(); 

            	    }
            	    break;
            	case 2 :
            	    // T:\\transfer-root\\antlr/Tql.g:291:16: DIGIT
            	    {
            	    mDIGIT(); 

            	    }
            	    break;
            	case 3 :
            	    // T:\\transfer-root\\antlr/Tql.g:291:22: '_'
            	    {
            	    match('_'); 

            	    }
            	    break;

            	default :
            	    break loop1;
                }
            } while (true);

             currentMode = STRING_MODE; 

            }



                    if ( token==null && ruleNestingLevel==1 ) {
                        emit(_type,_line,_charPosition,_channel,_start,getCharIndex()-1);
                    }

                    
        }
        finally {
            ruleNestingLevel--;
        }
    }
    // $ANTLR end ALIAS

    // $ANTLR start OPERATOR
    public void mOPERATOR() throws RecognitionException {
        try {
            ruleNestingLevel++;
            int _type = OPERATOR;
            int _start = getCharIndex();
            int _line = getLine();
            int _charPosition = getCharPositionInLine();
            int _channel = Token.DEFAULT_CHANNEL;
            // T:\\transfer-root\\antlr/Tql.g:296:2: ( ( '=' | '>' | '<' | '!=' | '<>' | '>=' | '<=' | 'like' ) )
            // T:\\transfer-root\\antlr/Tql.g:296:2: ( '=' | '>' | '<' | '!=' | '<>' | '>=' | '<=' | 'like' )
            {
            // T:\\transfer-root\\antlr/Tql.g:296:2: ( '=' | '>' | '<' | '!=' | '<>' | '>=' | '<=' | 'like' )
            int alt2=8;
            switch ( input.LA(1) ) {
            case '=':
                alt2=1;
                break;
            case '>':
                int LA2_2 = input.LA(2);
                if ( (LA2_2=='=') ) {
                    alt2=6;
                }
                else {
                    alt2=2;}
                break;
            case '<':
                switch ( input.LA(2) ) {
                case '>':
                    alt2=5;
                    break;
                case '=':
                    alt2=7;
                    break;
                default:
                    alt2=3;}

                break;
            case '!':
                alt2=4;
                break;
            case 'l':
                alt2=8;
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("296:2: ( '=' | '>' | '<' | '!=' | '<>' | '>=' | '<=' | 'like' )", 2, 0, input);

                throw nvae;
            }

            switch (alt2) {
                case 1 :
                    // T:\\transfer-root\\antlr/Tql.g:296:3: '='
                    {
                    match('='); 

                    }
                    break;
                case 2 :
                    // T:\\transfer-root\\antlr/Tql.g:296:7: '>'
                    {
                    match('>'); 

                    }
                    break;
                case 3 :
                    // T:\\transfer-root\\antlr/Tql.g:296:11: '<'
                    {
                    match('<'); 

                    }
                    break;
                case 4 :
                    // T:\\transfer-root\\antlr/Tql.g:296:15: '!='
                    {
                    match("!="); 


                    }
                    break;
                case 5 :
                    // T:\\transfer-root\\antlr/Tql.g:296:20: '<>'
                    {
                    match("<>"); 


                    }
                    break;
                case 6 :
                    // T:\\transfer-root\\antlr/Tql.g:296:25: '>='
                    {
                    match(">="); 


                    }
                    break;
                case 7 :
                    // T:\\transfer-root\\antlr/Tql.g:296:30: '<='
                    {
                    match("<="); 


                    }
                    break;
                case 8 :
                    // T:\\transfer-root\\antlr/Tql.g:296:35: 'like'
                    {
                    match("like"); 


                    }
                    break;

            }

             setMode(PROPERTY_IDENTIFIER_MODE); 

            }



                    if ( token==null && ruleNestingLevel==1 ) {
                        emit(_type,_line,_charPosition,_channel,_start,getCharIndex()-1);
                    }

                    
        }
        finally {
            ruleNestingLevel--;
        }
    }
    // $ANTLR end OPERATOR

    // $ANTLR start BOOLEAN_LOGIC
    public void mBOOLEAN_LOGIC() throws RecognitionException {
        try {
            ruleNestingLevel++;
            int _type = BOOLEAN_LOGIC;
            int _start = getCharIndex();
            int _line = getLine();
            int _charPosition = getCharPositionInLine();
            int _channel = Token.DEFAULT_CHANNEL;
            // T:\\transfer-root\\antlr/Tql.g:301:2: ({...}? => ( 'and' | 'or' ) )
            // T:\\transfer-root\\antlr/Tql.g:301:2: {...}? => ( 'and' | 'or' )
            {
            if ( !( currentMode == STRING_MODE ) ) {
                throw new FailedPredicateException(input, "BOOLEAN_LOGIC", " currentMode == STRING_MODE ");
            }
            // T:\\transfer-root\\antlr/Tql.g:302:2: ( 'and' | 'or' )
            int alt3=2;
            int LA3_0 = input.LA(1);
            if ( (LA3_0=='a') ) {
                alt3=1;
            }
            else if ( (LA3_0=='o') ) {
                alt3=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("302:2: ( 'and' | 'or' )", 3, 0, input);

                throw nvae;
            }
            switch (alt3) {
                case 1 :
                    // T:\\transfer-root\\antlr/Tql.g:302:4: 'and'
                    {
                    match("and"); 


                    }
                    break;
                case 2 :
                    // T:\\transfer-root\\antlr/Tql.g:302:12: 'or'
                    {
                    match("or"); 


                    }
                    break;

            }

             setMode(PROPERTY_IDENTIFIER_MODE); 

            }



                    if ( token==null && ruleNestingLevel==1 ) {
                        emit(_type,_line,_charPosition,_channel,_start,getCharIndex()-1);
                    }

                    
        }
        finally {
            ruleNestingLevel--;
        }
    }
    // $ANTLR end BOOLEAN_LOGIC

    // $ANTLR start IS
    public void mIS() throws RecognitionException {
        try {
            ruleNestingLevel++;
            int _type = IS;
            int _start = getCharIndex();
            int _line = getLine();
            int _charPosition = getCharPositionInLine();
            int _channel = Token.DEFAULT_CHANNEL;
            // T:\\transfer-root\\antlr/Tql.g:306:2: ({...}? => 'is' )
            // T:\\transfer-root\\antlr/Tql.g:306:2: {...}? => 'is'
            {
            if ( !( currentMode == STRING_MODE ) ) {
                throw new FailedPredicateException(input, "IS", " currentMode == STRING_MODE ");
            }
            match("is"); 


            }



                    if ( token==null && ruleNestingLevel==1 ) {
                        emit(_type,_line,_charPosition,_channel,_start,getCharIndex()-1);
                    }

                    
        }
        finally {
            ruleNestingLevel--;
        }
    }
    // $ANTLR end IS

    // $ANTLR start NOT
    public void mNOT() throws RecognitionException {
        try {
            ruleNestingLevel++;
            int _type = NOT;
            int _start = getCharIndex();
            int _line = getLine();
            int _charPosition = getCharPositionInLine();
            int _channel = Token.DEFAULT_CHANNEL;
            // T:\\transfer-root\\antlr/Tql.g:310:2: ({...}? => 'not' )
            // T:\\transfer-root\\antlr/Tql.g:310:2: {...}? => 'not'
            {
            if ( !( currentMode == STRING_MODE ) ) {
                throw new FailedPredicateException(input, "NOT", " currentMode == STRING_MODE ");
            }
            match("not"); 


            }



                    if ( token==null && ruleNestingLevel==1 ) {
                        emit(_type,_line,_charPosition,_channel,_start,getCharIndex()-1);
                    }

                    
        }
        finally {
            ruleNestingLevel--;
        }
    }
    // $ANTLR end NOT

    // $ANTLR start NULL
    public void mNULL() throws RecognitionException {
        try {
            ruleNestingLevel++;
            int _type = NULL;
            int _start = getCharIndex();
            int _line = getLine();
            int _charPosition = getCharPositionInLine();
            int _channel = Token.DEFAULT_CHANNEL;
            // T:\\transfer-root\\antlr/Tql.g:314:2: ({...}? => 'null' )
            // T:\\transfer-root\\antlr/Tql.g:314:2: {...}? => 'null'
            {
            if ( !( currentMode == STRING_MODE ) ) {
                throw new FailedPredicateException(input, "NULL", " currentMode == STRING_MODE ");
            }
            match("null"); 


            }



                    if ( token==null && ruleNestingLevel==1 ) {
                        emit(_type,_line,_charPosition,_channel,_start,getCharIndex()-1);
                    }

                    
        }
        finally {
            ruleNestingLevel--;
        }
    }
    // $ANTLR end NULL

    // $ANTLR start IN
    public void mIN() throws RecognitionException {
        try {
            ruleNestingLevel++;
            int _type = IN;
            int _start = getCharIndex();
            int _line = getLine();
            int _charPosition = getCharPositionInLine();
            int _channel = Token.DEFAULT_CHANNEL;
            // T:\\transfer-root\\antlr/Tql.g:318:2: ({...}? => 'in' )
            // T:\\transfer-root\\antlr/Tql.g:318:2: {...}? => 'in'
            {
            if ( !( currentMode == STRING_MODE ) ) {
                throw new FailedPredicateException(input, "IN", " currentMode == STRING_MODE ");
            }
            match("in"); 


            }



                    if ( token==null && ruleNestingLevel==1 ) {
                        emit(_type,_line,_charPosition,_channel,_start,getCharIndex()-1);
                    }

                    
        }
        finally {
            ruleNestingLevel--;
        }
    }
    // $ANTLR end IN

    // $ANTLR start LEFT
    public void mLEFT() throws RecognitionException {
        try {
            ruleNestingLevel++;
            int _type = LEFT;
            int _start = getCharIndex();
            int _line = getLine();
            int _charPosition = getCharPositionInLine();
            int _channel = Token.DEFAULT_CHANNEL;
            // T:\\transfer-root\\antlr/Tql.g:322:2: ({...}? => 'left' )
            // T:\\transfer-root\\antlr/Tql.g:322:2: {...}? => 'left'
            {
            if ( !( currentMode == STRING_MODE ) ) {
                throw new FailedPredicateException(input, "LEFT", " currentMode == STRING_MODE ");
            }
            match("left"); 


            }



                    if ( token==null && ruleNestingLevel==1 ) {
                        emit(_type,_line,_charPosition,_channel,_start,getCharIndex()-1);
                    }

                    
        }
        finally {
            ruleNestingLevel--;
        }
    }
    // $ANTLR end LEFT

    // $ANTLR start RIGHT
    public void mRIGHT() throws RecognitionException {
        try {
            ruleNestingLevel++;
            int _type = RIGHT;
            int _start = getCharIndex();
            int _line = getLine();
            int _charPosition = getCharPositionInLine();
            int _channel = Token.DEFAULT_CHANNEL;
            // T:\\transfer-root\\antlr/Tql.g:326:2: ({...}? => 'right' )
            // T:\\transfer-root\\antlr/Tql.g:326:2: {...}? => 'right'
            {
            if ( !( currentMode == STRING_MODE ) ) {
                throw new FailedPredicateException(input, "RIGHT", " currentMode == STRING_MODE ");
            }
            match("right"); 


            }



                    if ( token==null && ruleNestingLevel==1 ) {
                        emit(_type,_line,_charPosition,_channel,_start,getCharIndex()-1);
                    }

                    
        }
        finally {
            ruleNestingLevel--;
        }
    }
    // $ANTLR end RIGHT

    // $ANTLR start OUTER
    public void mOUTER() throws RecognitionException {
        try {
            ruleNestingLevel++;
            int _type = OUTER;
            int _start = getCharIndex();
            int _line = getLine();
            int _charPosition = getCharPositionInLine();
            int _channel = Token.DEFAULT_CHANNEL;
            // T:\\transfer-root\\antlr/Tql.g:330:2: ({...}? => 'outer' )
            // T:\\transfer-root\\antlr/Tql.g:330:2: {...}? => 'outer'
            {
            if ( !( currentMode == STRING_MODE ) ) {
                throw new FailedPredicateException(input, "OUTER", " currentMode == STRING_MODE ");
            }
            match("outer"); 


            }



                    if ( token==null && ruleNestingLevel==1 ) {
                        emit(_type,_line,_charPosition,_channel,_start,getCharIndex()-1);
                    }

                    
        }
        finally {
            ruleNestingLevel--;
        }
    }
    // $ANTLR end OUTER

    // $ANTLR start JOIN
    public void mJOIN() throws RecognitionException {
        try {
            ruleNestingLevel++;
            int _type = JOIN;
            int _start = getCharIndex();
            int _line = getLine();
            int _charPosition = getCharPositionInLine();
            int _channel = Token.DEFAULT_CHANNEL;
            // T:\\transfer-root\\antlr/Tql.g:334:2: ({...}? => 'join' )
            // T:\\transfer-root\\antlr/Tql.g:334:2: {...}? => 'join'
            {
            if ( !( currentMode == STRING_MODE ) ) {
                throw new FailedPredicateException(input, "JOIN", " currentMode == STRING_MODE ");
            }
            match("join"); 

             setMode(CLASS_IDENTIFIER_MODE); 

            }



                    if ( token==null && ruleNestingLevel==1 ) {
                        emit(_type,_line,_charPosition,_channel,_start,getCharIndex()-1);
                    }

                    
        }
        finally {
            ruleNestingLevel--;
        }
    }
    // $ANTLR end JOIN

    // $ANTLR start ON
    public void mON() throws RecognitionException {
        try {
            ruleNestingLevel++;
            int _type = ON;
            int _start = getCharIndex();
            int _line = getLine();
            int _charPosition = getCharPositionInLine();
            int _channel = Token.DEFAULT_CHANNEL;
            // T:\\transfer-root\\antlr/Tql.g:339:2: ({...}? => 'on' )
            // T:\\transfer-root\\antlr/Tql.g:339:2: {...}? => 'on'
            {
            if ( !( currentMode == STRING_MODE ) ) {
                throw new FailedPredicateException(input, "ON", " currentMode == STRING_MODE ");
            }
            match("on"); 

             setMode(PROPERTY_IDENTIFIER_MODE); 

            }



                    if ( token==null && ruleNestingLevel==1 ) {
                        emit(_type,_line,_charPosition,_channel,_start,getCharIndex()-1);
                    }

                    
        }
        finally {
            ruleNestingLevel--;
        }
    }
    // $ANTLR end ON

    // $ANTLR start ORDER
    public void mORDER() throws RecognitionException {
        try {
            ruleNestingLevel++;
            int _type = ORDER;
            int _start = getCharIndex();
            int _line = getLine();
            int _charPosition = getCharPositionInLine();
            int _channel = Token.DEFAULT_CHANNEL;
            // T:\\transfer-root\\antlr/Tql.g:344:2: ({...}? => 'order' )
            // T:\\transfer-root\\antlr/Tql.g:344:2: {...}? => 'order'
            {
            if ( !( currentMode == STRING_MODE ) ) {
                throw new FailedPredicateException(input, "ORDER", " currentMode == STRING_MODE ");
            }
            match("order"); 


            }



                    if ( token==null && ruleNestingLevel==1 ) {
                        emit(_type,_line,_charPosition,_channel,_start,getCharIndex()-1);
                    }

                    
        }
        finally {
            ruleNestingLevel--;
        }
    }
    // $ANTLR end ORDER

    // $ANTLR start BY
    public void mBY() throws RecognitionException {
        try {
            ruleNestingLevel++;
            int _type = BY;
            int _start = getCharIndex();
            int _line = getLine();
            int _charPosition = getCharPositionInLine();
            int _channel = Token.DEFAULT_CHANNEL;
            // T:\\transfer-root\\antlr/Tql.g:348:2: ({...}? => 'by' )
            // T:\\transfer-root\\antlr/Tql.g:348:2: {...}? => 'by'
            {
            if ( !( currentMode == STRING_MODE ) ) {
                throw new FailedPredicateException(input, "BY", " currentMode == STRING_MODE ");
            }
            match("by"); 

             setMode(PROPERTY_IDENTIFIER_MODE); 

            }



                    if ( token==null && ruleNestingLevel==1 ) {
                        emit(_type,_line,_charPosition,_channel,_start,getCharIndex()-1);
                    }

                    
        }
        finally {
            ruleNestingLevel--;
        }
    }
    // $ANTLR end BY

    // $ANTLR start ASC_DESC
    public void mASC_DESC() throws RecognitionException {
        try {
            ruleNestingLevel++;
            int _type = ASC_DESC;
            int _start = getCharIndex();
            int _line = getLine();
            int _charPosition = getCharPositionInLine();
            int _channel = Token.DEFAULT_CHANNEL;
            // T:\\transfer-root\\antlr/Tql.g:354:2: ({...}? => 'asc' | 'desc' )
            int alt4=2;
            int LA4_0 = input.LA(1);
            if ( (LA4_0=='a') && ( currentMode == STRING_MODE )) {
                alt4=1;
            }
            else if ( (LA4_0=='d') ) {
                alt4=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("352:1: ASC_DESC : ({...}? => 'asc' | 'desc' );", 4, 0, input);

                throw nvae;
            }
            switch (alt4) {
                case 1 :
                    // T:\\transfer-root\\antlr/Tql.g:354:2: {...}? => 'asc'
                    {
                    if ( !( currentMode == STRING_MODE ) ) {
                        throw new FailedPredicateException(input, "ASC_DESC", " currentMode == STRING_MODE ");
                    }
                    match("asc"); 


                    }
                    break;
                case 2 :
                    // T:\\transfer-root\\antlr/Tql.g:355:10: 'desc'
                    {
                    match("desc"); 


                    }
                    break;

            }


                    if ( token==null && ruleNestingLevel==1 ) {
                        emit(_type,_line,_charPosition,_channel,_start,getCharIndex()-1);
                    }

                    
        }
        finally {
            ruleNestingLevel--;
        }
    }
    // $ANTLR end ASC_DESC

    // $ANTLR start LEFT_PAREN
    public void mLEFT_PAREN() throws RecognitionException {
        try {
            ruleNestingLevel++;
            int _type = LEFT_PAREN;
            int _start = getCharIndex();
            int _line = getLine();
            int _charPosition = getCharPositionInLine();
            int _channel = Token.DEFAULT_CHANNEL;
            // T:\\transfer-root\\antlr/Tql.g:359:2: ( '(' )
            // T:\\transfer-root\\antlr/Tql.g:359:2: '('
            {
            match('('); 

            }



                    if ( token==null && ruleNestingLevel==1 ) {
                        emit(_type,_line,_charPosition,_channel,_start,getCharIndex()-1);
                    }

                    
        }
        finally {
            ruleNestingLevel--;
        }
    }
    // $ANTLR end LEFT_PAREN

    // $ANTLR start RIGHT_PAREN
    public void mRIGHT_PAREN() throws RecognitionException {
        try {
            ruleNestingLevel++;
            int _type = RIGHT_PAREN;
            int _start = getCharIndex();
            int _line = getLine();
            int _charPosition = getCharPositionInLine();
            int _channel = Token.DEFAULT_CHANNEL;
            // T:\\transfer-root\\antlr/Tql.g:363:2: ( ')' )
            // T:\\transfer-root\\antlr/Tql.g:363:2: ')'
            {
            match(')'); 

            }



                    if ( token==null && ruleNestingLevel==1 ) {
                        emit(_type,_line,_charPosition,_channel,_start,getCharIndex()-1);
                    }

                    
        }
        finally {
            ruleNestingLevel--;
        }
    }
    // $ANTLR end RIGHT_PAREN

    // $ANTLR start MAPPED_PARAM
    public void mMAPPED_PARAM() throws RecognitionException {
        try {
            ruleNestingLevel++;
            int _type = MAPPED_PARAM;
            int _start = getCharIndex();
            int _line = getLine();
            int _charPosition = getCharPositionInLine();
            int _channel = Token.DEFAULT_CHANNEL;
            // T:\\transfer-root\\antlr/Tql.g:367:2: ( ':' ( LETTER | DIGIT | '_' )+ )
            // T:\\transfer-root\\antlr/Tql.g:367:2: ':' ( LETTER | DIGIT | '_' )+
            {
            match(':'); 
            // T:\\transfer-root\\antlr/Tql.g:367:5: ( LETTER | DIGIT | '_' )+
            int cnt5=0;
            loop5:
            do {
                int alt5=4;
                switch ( input.LA(1) ) {
                case 'a':
                case 'b':
                case 'c':
                case 'd':
                case 'e':
                case 'f':
                case 'g':
                case 'h':
                case 'i':
                case 'j':
                case 'k':
                case 'l':
                case 'm':
                case 'n':
                case 'o':
                case 'p':
                case 'q':
                case 'r':
                case 's':
                case 't':
                case 'u':
                case 'v':
                case 'w':
                case 'x':
                case 'y':
                case 'z':
                    alt5=1;
                    break;
                case '0':
                case '1':
                case '2':
                case '3':
                case '4':
                case '5':
                case '6':
                case '7':
                case '8':
                case '9':
                    alt5=2;
                    break;
                case '_':
                    alt5=3;
                    break;

                }

                switch (alt5) {
            	case 1 :
            	    // T:\\transfer-root\\antlr/Tql.g:367:6: LETTER
            	    {
            	    mLETTER(); 

            	    }
            	    break;
            	case 2 :
            	    // T:\\transfer-root\\antlr/Tql.g:367:13: DIGIT
            	    {
            	    mDIGIT(); 

            	    }
            	    break;
            	case 3 :
            	    // T:\\transfer-root\\antlr/Tql.g:367:19: '_'
            	    {
            	    match('_'); 

            	    }
            	    break;

            	default :
            	    if ( cnt5 >= 1 ) break loop5;
                        EarlyExitException eee =
                            new EarlyExitException(5, input);
                        throw eee;
                }
                cnt5++;
            } while (true);

             setMode(STRING_MODE);  

            }



                    if ( token==null && ruleNestingLevel==1 ) {
                        emit(_type,_line,_charPosition,_channel,_start,getCharIndex()-1);
                    }

                    
        }
        finally {
            ruleNestingLevel--;
        }
    }
    // $ANTLR end MAPPED_PARAM

    // $ANTLR start CLASS_IDENTIFIER
    public void mCLASS_IDENTIFIER() throws RecognitionException {
        try {
            ruleNestingLevel++;
            int _type = CLASS_IDENTIFIER;
            int _start = getCharIndex();
            int _line = getLine();
            int _charPosition = getCharPositionInLine();
            int _channel = Token.DEFAULT_CHANNEL;
            // T:\\transfer-root\\antlr/Tql.g:372:2: ({...}? => IDENTIFIER )
            // T:\\transfer-root\\antlr/Tql.g:372:2: {...}? => IDENTIFIER
            {
            if ( !( currentMode == CLASS_IDENTIFIER_MODE ) ) {
                throw new FailedPredicateException(input, "CLASS_IDENTIFIER", " currentMode == CLASS_IDENTIFIER_MODE ");
            }
            mIDENTIFIER(); 
             setMode(STRING_MODE);  

            }



                    if ( token==null && ruleNestingLevel==1 ) {
                        emit(_type,_line,_charPosition,_channel,_start,getCharIndex()-1);
                    }

                    
        }
        finally {
            ruleNestingLevel--;
        }
    }
    // $ANTLR end CLASS_IDENTIFIER

    // $ANTLR start PROPERTY_IDENTIFIER
    public void mPROPERTY_IDENTIFIER() throws RecognitionException {
        try {
            ruleNestingLevel++;
            int _type = PROPERTY_IDENTIFIER;
            int _start = getCharIndex();
            int _line = getLine();
            int _charPosition = getCharPositionInLine();
            int _channel = Token.DEFAULT_CHANNEL;
            // T:\\transfer-root\\antlr/Tql.g:378:2: ({...}? => IDENTIFIER )
            // T:\\transfer-root\\antlr/Tql.g:378:2: {...}? => IDENTIFIER
            {
            if ( !( currentMode == PROPERTY_IDENTIFIER_MODE ) ) {
                throw new FailedPredicateException(input, "PROPERTY_IDENTIFIER", " currentMode == PROPERTY_IDENTIFIER_MODE ");
            }
            mIDENTIFIER(); 
             setMode(STRING_MODE);  

            }



                    if ( token==null && ruleNestingLevel==1 ) {
                        emit(_type,_line,_charPosition,_channel,_start,getCharIndex()-1);
                    }

                    
        }
        finally {
            ruleNestingLevel--;
        }
    }
    // $ANTLR end PROPERTY_IDENTIFIER

    // $ANTLR start ASTERISK
    public void mASTERISK() throws RecognitionException {
        try {
            ruleNestingLevel++;
            int _type = ASTERISK;
            int _start = getCharIndex();
            int _line = getLine();
            int _charPosition = getCharPositionInLine();
            int _channel = Token.DEFAULT_CHANNEL;
            // T:\\transfer-root\\antlr/Tql.g:384:2: ( '*' )
            // T:\\transfer-root\\antlr/Tql.g:384:2: '*'
            {
            match('*'); 
             setMode(STRING_MODE);  

            }



                    if ( token==null && ruleNestingLevel==1 ) {
                        emit(_type,_line,_charPosition,_channel,_start,getCharIndex()-1);
                    }

                    
        }
        finally {
            ruleNestingLevel--;
        }
    }
    // $ANTLR end ASTERISK

    // $ANTLR start WS
    public void mWS() throws RecognitionException {
        try {
            ruleNestingLevel++;
            int _type = WS;
            int _start = getCharIndex();
            int _line = getLine();
            int _charPosition = getCharPositionInLine();
            int _channel = Token.DEFAULT_CHANNEL;
            // T:\\transfer-root\\antlr/Tql.g:388:2: ( (' '|'\\r'|'\\t'|'\\u000C'|'\\n'))
            // T:\\transfer-root\\antlr/Tql.g:388:2: (' '|'\\r'|'\\t'|'\\u000C'|'\\n')
            {
            if ( (input.LA(1)>='\t' && input.LA(1)<='\n')||(input.LA(1)>='\f' && input.LA(1)<='\r')||input.LA(1)==' ' ) {
                input.consume();

            }
            else {
                MismatchedSetException mse =
                    new MismatchedSetException(null,input);
                recover(mse);    throw mse;
            }

             
            		_channel=HIDDEN; 
            	

            }



                    if ( token==null && ruleNestingLevel==1 ) {
                        emit(_type,_line,_charPosition,_channel,_start,getCharIndex()-1);
                    }

                    
        }
        finally {
            ruleNestingLevel--;
        }
    }
    // $ANTLR end WS

    // $ANTLR start IDENTIFIER
    public void mIDENTIFIER() throws RecognitionException {
        try {
            ruleNestingLevel++;
            // T:\\transfer-root\\antlr/Tql.g:395:2: ( LETTER ( LETTER | DIGIT | '.' | '_' )+ )
            // T:\\transfer-root\\antlr/Tql.g:395:2: LETTER ( LETTER | DIGIT | '.' | '_' )+
            {
            mLETTER(); 
            // T:\\transfer-root\\antlr/Tql.g:395:8: ( LETTER | DIGIT | '.' | '_' )+
            int cnt6=0;
            loop6:
            do {
                int alt6=5;
                switch ( input.LA(1) ) {
                case 'a':
                case 'b':
                case 'c':
                case 'd':
                case 'e':
                case 'f':
                case 'g':
                case 'h':
                case 'i':
                case 'j':
                case 'k':
                case 'l':
                case 'm':
                case 'n':
                case 'o':
                case 'p':
                case 'q':
                case 'r':
                case 's':
                case 't':
                case 'u':
                case 'v':
                case 'w':
                case 'x':
                case 'y':
                case 'z':
                    alt6=1;
                    break;
                case '0':
                case '1':
                case '2':
                case '3':
                case '4':
                case '5':
                case '6':
                case '7':
                case '8':
                case '9':
                    alt6=2;
                    break;
                case '.':
                    alt6=3;
                    break;
                case '_':
                    alt6=4;
                    break;

                }

                switch (alt6) {
            	case 1 :
            	    // T:\\transfer-root\\antlr/Tql.g:395:9: LETTER
            	    {
            	    mLETTER(); 

            	    }
            	    break;
            	case 2 :
            	    // T:\\transfer-root\\antlr/Tql.g:395:16: DIGIT
            	    {
            	    mDIGIT(); 

            	    }
            	    break;
            	case 3 :
            	    // T:\\transfer-root\\antlr/Tql.g:395:22: '.'
            	    {
            	    match('.'); 

            	    }
            	    break;
            	case 4 :
            	    // T:\\transfer-root\\antlr/Tql.g:395:26: '_'
            	    {
            	    match('_'); 

            	    }
            	    break;

            	default :
            	    if ( cnt6 >= 1 ) break loop6;
                        EarlyExitException eee =
                            new EarlyExitException(6, input);
                        throw eee;
                }
                cnt6++;
            } while (true);


            }

        }
        finally {
            ruleNestingLevel--;
        }
    }
    // $ANTLR end IDENTIFIER

    // $ANTLR start DIGIT
    public void mDIGIT() throws RecognitionException {
        try {
            ruleNestingLevel++;
            // T:\\transfer-root\\antlr/Tql.g:399:2: ( '0' .. '9' )
            // T:\\transfer-root\\antlr/Tql.g:399:2: '0' .. '9'
            {
            matchRange('0','9'); 

            }

        }
        finally {
            ruleNestingLevel--;
        }
    }
    // $ANTLR end DIGIT

    // $ANTLR start LETTER
    public void mLETTER() throws RecognitionException {
        try {
            ruleNestingLevel++;
            // T:\\transfer-root\\antlr/Tql.g:403:2: ( 'a' .. 'z' )
            // T:\\transfer-root\\antlr/Tql.g:403:2: 'a' .. 'z'
            {
            matchRange('a','z'); 

            }

        }
        finally {
            ruleNestingLevel--;
        }
    }
    // $ANTLR end LETTER

    public void mTokens() throws RecognitionException {
        // T:\\transfer-root\\antlr/Tql.g:1:10: ( SELECT | FROM | WHERE | COMMA | AS | ALIAS | OPERATOR | BOOLEAN_LOGIC | IS | NOT | NULL | IN | LEFT | RIGHT | OUTER | JOIN | ON | ORDER | BY | ASC_DESC | LEFT_PAREN | RIGHT_PAREN | MAPPED_PARAM | CLASS_IDENTIFIER | PROPERTY_IDENTIFIER | ASTERISK | WS )
        int alt7=27;
        alt7 = dfa7.predict(input);
        switch (alt7) {
            case 1 :
                // T:\\transfer-root\\antlr/Tql.g:1:10: SELECT
                {
                mSELECT(); 

                }
                break;
            case 2 :
                // T:\\transfer-root\\antlr/Tql.g:1:17: FROM
                {
                mFROM(); 

                }
                break;
            case 3 :
                // T:\\transfer-root\\antlr/Tql.g:1:22: WHERE
                {
                mWHERE(); 

                }
                break;
            case 4 :
                // T:\\transfer-root\\antlr/Tql.g:1:28: COMMA
                {
                mCOMMA(); 

                }
                break;
            case 5 :
                // T:\\transfer-root\\antlr/Tql.g:1:34: AS
                {
                mAS(); 

                }
                break;
            case 6 :
                // T:\\transfer-root\\antlr/Tql.g:1:37: ALIAS
                {
                mALIAS(); 

                }
                break;
            case 7 :
                // T:\\transfer-root\\antlr/Tql.g:1:43: OPERATOR
                {
                mOPERATOR(); 

                }
                break;
            case 8 :
                // T:\\transfer-root\\antlr/Tql.g:1:52: BOOLEAN_LOGIC
                {
                mBOOLEAN_LOGIC(); 

                }
                break;
            case 9 :
                // T:\\transfer-root\\antlr/Tql.g:1:66: IS
                {
                mIS(); 

                }
                break;
            case 10 :
                // T:\\transfer-root\\antlr/Tql.g:1:69: NOT
                {
                mNOT(); 

                }
                break;
            case 11 :
                // T:\\transfer-root\\antlr/Tql.g:1:73: NULL
                {
                mNULL(); 

                }
                break;
            case 12 :
                // T:\\transfer-root\\antlr/Tql.g:1:78: IN
                {
                mIN(); 

                }
                break;
            case 13 :
                // T:\\transfer-root\\antlr/Tql.g:1:81: LEFT
                {
                mLEFT(); 

                }
                break;
            case 14 :
                // T:\\transfer-root\\antlr/Tql.g:1:86: RIGHT
                {
                mRIGHT(); 

                }
                break;
            case 15 :
                // T:\\transfer-root\\antlr/Tql.g:1:92: OUTER
                {
                mOUTER(); 

                }
                break;
            case 16 :
                // T:\\transfer-root\\antlr/Tql.g:1:98: JOIN
                {
                mJOIN(); 

                }
                break;
            case 17 :
                // T:\\transfer-root\\antlr/Tql.g:1:103: ON
                {
                mON(); 

                }
                break;
            case 18 :
                // T:\\transfer-root\\antlr/Tql.g:1:106: ORDER
                {
                mORDER(); 

                }
                break;
            case 19 :
                // T:\\transfer-root\\antlr/Tql.g:1:112: BY
                {
                mBY(); 

                }
                break;
            case 20 :
                // T:\\transfer-root\\antlr/Tql.g:1:115: ASC_DESC
                {
                mASC_DESC(); 

                }
                break;
            case 21 :
                // T:\\transfer-root\\antlr/Tql.g:1:124: LEFT_PAREN
                {
                mLEFT_PAREN(); 

                }
                break;
            case 22 :
                // T:\\transfer-root\\antlr/Tql.g:1:135: RIGHT_PAREN
                {
                mRIGHT_PAREN(); 

                }
                break;
            case 23 :
                // T:\\transfer-root\\antlr/Tql.g:1:147: MAPPED_PARAM
                {
                mMAPPED_PARAM(); 

                }
                break;
            case 24 :
                // T:\\transfer-root\\antlr/Tql.g:1:160: CLASS_IDENTIFIER
                {
                mCLASS_IDENTIFIER(); 

                }
                break;
            case 25 :
                // T:\\transfer-root\\antlr/Tql.g:1:177: PROPERTY_IDENTIFIER
                {
                mPROPERTY_IDENTIFIER(); 

                }
                break;
            case 26 :
                // T:\\transfer-root\\antlr/Tql.g:1:197: ASTERISK
                {
                mASTERISK(); 

                }
                break;
            case 27 :
                // T:\\transfer-root\\antlr/Tql.g:1:206: WS
                {
                mWS(); 

                }
                break;

        }

    }


    protected DFA7 dfa7 = new DFA7(this);
    public static final String DFA7_eotS =
        "\1\uffff\3\26\1\uffff\2\26\1\uffff\10\26\5\uffff\1\55\1\uffff\2"+
        "\55\1\56\3\55\1\65\3\55\1\72\1\55\1\74\1\75\1\76\4\55\1\103\2\55"+
        "\2\uffff\3\56\2\55\1\112\1\uffff\1\72\3\55\1\uffff\1\55\3\uffff"+
        "\1\124\3\55\1\uffff\2\55\2\uffff\1\133\1\55\2\uffff\1\136\1\137"+
        "\1\55\1\uffff\1\55\4\uffff\1\143\1\55\1\145\1\uffff\1\146\1\55\1"+
        "\uffff\1\151\3\uffff\1\153\1\154\2\uffff\1\156\2\uffff\1\161\17"+
        "\uffff";
    public static final String DFA7_eofS =
        "\167\uffff";
    public static final String DFA7_minS =
        "\1\11\3\56\1\uffff\2\56\1\uffff\10\56\5\uffff\1\56\1\uffff\26\56"+
        "\2\0\6\56\1\0\4\56\1\0\1\56\3\0\4\56\1\0\2\56\2\uffff\2\56\1\0\1"+
        "\uffff\3\56\1\uffff\1\56\3\uffff\1\0\3\56\1\uffff\2\56\1\0\1\56"+
        "\1\uffff\2\0\2\56\1\uffff\1\0\1\56\2\0\1\56\1\uffff\1\0\1\uffff"+
        "\2\0\1\uffff\1\0\2\uffff\1\0\5\uffff";
    public static final String DFA7_maxS =
        "\4\172\1\uffff\2\172\1\uffff\10\172\5\uffff\1\172\1\uffff\26\172"+
        "\2\0\6\172\1\0\4\172\1\0\1\172\3\0\4\172\1\0\2\172\2\uffff\2\172"+
        "\1\0\1\uffff\3\172\1\uffff\1\172\3\uffff\1\0\3\172\1\uffff\2\172"+
        "\1\0\1\172\1\uffff\2\0\2\172\1\uffff\1\0\1\172\2\0\1\172\1\uffff"+
        "\1\0\1\uffff\2\0\1\uffff\1\0\2\uffff\1\0\5\uffff";
    public static final String DFA7_acceptS =
        "\4\uffff\1\4\2\uffff\1\7\10\uffff\1\25\1\26\1\27\1\32\1\33\1\uffff"+
        "\1\6\57\uffff\1\30\1\31\3\uffff\1\5\3\uffff\1\10\1\uffff\1\21\1"+
        "\14\1\11\4\uffff\1\23\4\uffff\1\24\4\uffff\1\12\5\uffff\1\2\1\uffff"+
        "\1\15\2\uffff\1\13\1\uffff\1\20\1\24\1\uffff\1\3\1\22\1\17\1\16"+
        "\1\1";
    public static final String DFA7_specialS =
        "\1\3\1\45\1\55\1\21\1\uffff\1\61\1\1\1\uffff\1\104\1\31\1\11\1\15"+
        "\1\44\1\75\1\121\1\4\5\uffff\1\26\1\uffff\1\105\1\70\1\33\1\66\1"+
        "\20\1\67\1\110\1\102\1\100\1\117\1\7\1\30\1\127\1\107\1\5\1\52\1"+
        "\0\1\63\1\64\1\60\1\36\1\72\1\65\1\126\1\34\1\16\1\27\1\35\1\101"+
        "\1\114\1\111\1\113\1\120\1\122\1\106\1\57\1\32\1\43\1\12\1\115\1"+
        "\54\1\37\1\77\1\51\1\50\1\42\1\24\2\uffff\1\25\1\41\1\74\1\uffff"+
        "\1\40\1\56\1\130\1\uffff\1\6\3\uffff\1\103\1\14\1\125\1\13\1\uffff"+
        "\1\22\1\23\1\2\1\62\1\uffff\1\17\1\53\1\132\1\76\1\uffff\1\10\1"+
        "\46\1\124\1\73\1\71\1\uffff\1\131\1\uffff\1\47\1\112\1\uffff\1\116"+
        "\2\uffff\1\123\5\uffff}>";
    public static final String[] DFA7_transition = {
        "\2\24\1\uffff\2\24\22\uffff\1\24\1\7\6\uffff\1\20\1\21\1\23\1\uffff"+
        "\1\4\15\uffff\1\22\1\uffff\3\7\42\uffff\1\5\1\15\1\17\1\16\1\17"+
        "\1\2\2\17\1\11\1\14\1\17\1\6\1\17\1\12\1\10\2\17\1\13\1\1\3\17\1"+
        "\3\3\17",
        "\1\31\1\uffff\12\30\45\uffff\1\32\1\uffff\4\27\1\25\25\27",
        "\1\31\1\uffff\12\30\45\uffff\1\32\1\uffff\21\27\1\33\10\27",
        "\1\31\1\uffff\12\30\45\uffff\1\32\1\uffff\7\27\1\34\22\27",
        "",
        "\1\31\1\uffff\12\30\45\uffff\1\32\1\uffff\15\27\1\36\4\27\1\35\7"+
        "\27",
        "\1\31\1\uffff\12\30\45\uffff\1\32\1\uffff\4\27\1\37\3\27\1\40\21"+
        "\27",
        "",
        "\1\31\1\uffff\12\30\45\uffff\1\32\1\uffff\15\27\1\43\3\27\1\41\2"+
        "\27\1\42\5\27",
        "\1\31\1\uffff\12\30\45\uffff\1\32\1\uffff\15\27\1\44\4\27\1\45\7"+
        "\27",
        "\1\31\1\uffff\12\30\45\uffff\1\32\1\uffff\16\27\1\46\5\27\1\47\5"+
        "\27",
        "\1\31\1\uffff\12\30\45\uffff\1\32\1\uffff\10\27\1\50\21\27",
        "\1\31\1\uffff\12\30\45\uffff\1\32\1\uffff\16\27\1\51\13\27",
        "\1\31\1\uffff\12\30\45\uffff\1\32\1\uffff\30\27\1\52\1\27",
        "\1\31\1\uffff\12\30\45\uffff\1\32\1\uffff\4\27\1\53\25\27",
        "\1\31\1\uffff\12\30\45\uffff\1\32\1\uffff\32\27",
        "",
        "",
        "",
        "",
        "",
        "\1\31\1\uffff\12\30\45\uffff\1\32\1\uffff\13\27\1\54\16\27",
        "",
        "\1\31\1\uffff\12\30\45\uffff\1\32\1\uffff\32\27",
        "\1\31\1\uffff\12\30\45\uffff\1\32\1\uffff\32\27",
        "\1\31\1\uffff\12\60\45\uffff\1\61\1\uffff\32\57",
        "\1\31\1\uffff\12\30\45\uffff\1\32\1\uffff\32\27",
        "\1\31\1\uffff\12\30\45\uffff\1\32\1\uffff\16\27\1\62\13\27",
        "\1\31\1\uffff\12\30\45\uffff\1\32\1\uffff\4\27\1\63\25\27",
        "\1\31\1\uffff\12\30\45\uffff\1\32\1\uffff\2\27\1\64\27\27",
        "\1\31\1\uffff\12\30\45\uffff\1\32\1\uffff\3\27\1\66\26\27",
        "\1\31\1\uffff\12\30\45\uffff\1\32\1\uffff\5\27\1\67\24\27",
        "\1\31\1\uffff\12\30\45\uffff\1\32\1\uffff\12\27\1\70\17\27",
        "\1\31\1\uffff\12\30\45\uffff\1\32\1\uffff\3\27\1\71\26\27",
        "\1\31\1\uffff\12\30\45\uffff\1\32\1\uffff\23\27\1\73\6\27",
        "\1\31\1\uffff\12\30\45\uffff\1\32\1\uffff\32\27",
        "\1\31\1\uffff\12\30\45\uffff\1\32\1\uffff\32\27",
        "\1\31\1\uffff\12\30\45\uffff\1\32\1\uffff\32\27",
        "\1\31\1\uffff\12\30\45\uffff\1\32\1\uffff\23\27\1\77\6\27",
        "\1\31\1\uffff\12\30\45\uffff\1\32\1\uffff\13\27\1\100\16\27",
        "\1\31\1\uffff\12\30\45\uffff\1\32\1\uffff\6\27\1\101\23\27",
        "\1\31\1\uffff\12\30\45\uffff\1\32\1\uffff\10\27\1\102\21\27",
        "\1\31\1\uffff\12\30\45\uffff\1\32\1\uffff\32\27",
        "\1\31\1\uffff\12\30\45\uffff\1\32\1\uffff\22\27\1\104\7\27",
        "\1\31\1\uffff\12\30\45\uffff\1\32\1\uffff\4\27\1\105\25\27",
        "\1\uffff",
        "\1\uffff",
        "\1\31\1\uffff\12\60\45\uffff\1\61\1\uffff\32\57",
        "\1\31\1\uffff\12\60\45\uffff\1\61\1\uffff\32\57",
        "\1\31\1\uffff\12\60\45\uffff\1\61\1\uffff\32\57",
        "\1\31\1\uffff\12\30\45\uffff\1\32\1\uffff\14\27\1\110\15\27",
        "\1\31\1\uffff\12\30\45\uffff\1\32\1\uffff\21\27\1\111\10\27",
        "\1\31\1\uffff\12\30\45\uffff\1\32\1\uffff\32\27",
        "\1\uffff",
        "\1\31\1\uffff\12\30\45\uffff\1\32\1\uffff\32\27",
        "\1\31\1\uffff\12\30\45\uffff\1\32\1\uffff\23\27\1\114\6\27",
        "\1\31\1\uffff\12\30\45\uffff\1\32\1\uffff\4\27\1\115\25\27",
        "\1\31\1\uffff\12\30\45\uffff\1\32\1\uffff\4\27\1\116\25\27",
        "\1\uffff",
        "\1\31\1\uffff\12\30\45\uffff\1\32\1\uffff\4\27\1\120\25\27",
        "\1\uffff",
        "\1\uffff",
        "\1\uffff",
        "\1\31\1\uffff\12\30\45\uffff\1\32\1\uffff\32\27",
        "\1\31\1\uffff\12\30\45\uffff\1\32\1\uffff\13\27\1\125\16\27",
        "\1\31\1\uffff\12\30\45\uffff\1\32\1\uffff\7\27\1\126\22\27",
        "\1\31\1\uffff\12\30\45\uffff\1\32\1\uffff\15\27\1\127\14\27",
        "\1\uffff",
        "\1\31\1\uffff\12\30\45\uffff\1\32\1\uffff\2\27\1\131\27\27",
        "\1\31\1\uffff\12\30\45\uffff\1\32\1\uffff\2\27\1\132\27\27",
        "",
        "",
        "\1\31\1\uffff\12\30\45\uffff\1\32\1\uffff\32\27",
        "\1\31\1\uffff\12\30\45\uffff\1\32\1\uffff\4\27\1\134\25\27",
        "\1\uffff",
        "",
        "\1\31\1\uffff\12\30\45\uffff\1\32\1\uffff\32\27",
        "\1\31\1\uffff\12\30\45\uffff\1\32\1\uffff\32\27",
        "\1\31\1\uffff\12\30\45\uffff\1\32\1\uffff\21\27\1\140\10\27",
        "",
        "\1\31\1\uffff\12\30\45\uffff\1\32\1\uffff\21\27\1\141\10\27",
        "",
        "",
        "",
        "\1\uffff",
        "\1\31\1\uffff\12\30\45\uffff\1\32\1\uffff\32\27",
        "\1\31\1\uffff\12\30\45\uffff\1\32\1\uffff\23\27\1\144\6\27",
        "\1\31\1\uffff\12\30\45\uffff\1\32\1\uffff\32\27",
        "",
        "\1\31\1\uffff\12\30\45\uffff\1\32\1\uffff\32\27",
        "\1\31\1\uffff\12\30\45\uffff\1\32\1\uffff\23\27\1\147\6\27",
        "\1\uffff",
        "\1\31\1\uffff\12\30\45\uffff\1\32\1\uffff\32\27",
        "",
        "\1\uffff",
        "\1\uffff",
        "\1\31\1\uffff\12\30\45\uffff\1\32\1\uffff\32\27",
        "\1\31\1\uffff\12\30\45\uffff\1\32\1\uffff\32\27",
        "",
        "\1\uffff",
        "\1\31\1\uffff\12\30\45\uffff\1\32\1\uffff\32\27",
        "\1\uffff",
        "\1\uffff",
        "\1\31\1\uffff\12\30\45\uffff\1\32\1\uffff\32\27",
        "",
        "\1\uffff",
        "",
        "\1\uffff",
        "\1\uffff",
        "",
        "\1\uffff",
        "",
        "",
        "\1\uffff",
        "",
        "",
        "",
        "",
        ""
    };

    class DFA7 extends DFA {
        public DFA7(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 7;
            this.eot = DFA.unpackEncodedString(DFA7_eotS);
            this.eof = DFA.unpackEncodedString(DFA7_eofS);
            this.min = DFA.unpackEncodedStringToUnsignedChars(DFA7_minS);
            this.max = DFA.unpackEncodedStringToUnsignedChars(DFA7_maxS);
            this.accept = DFA.unpackEncodedString(DFA7_acceptS);
            this.special = DFA.unpackEncodedString(DFA7_specialS);
            int numStates = DFA7_transition.length;
            this.transition = new short[numStates][];
            for (int i=0; i<numStates; i++) {
                transition[i] = DFA.unpackEncodedString(DFA7_transition[i]);
            }
        }
        public String getDescription() {
            return "1:1: Tokens : ( SELECT | FROM | WHERE | COMMA | AS | ALIAS | OPERATOR | BOOLEAN_LOGIC | IS | NOT | NULL | IN | LEFT | RIGHT | OUTER | JOIN | ON | ORDER | BY | ASC_DESC | LEFT_PAREN | RIGHT_PAREN | MAPPED_PARAM | CLASS_IDENTIFIER | PROPERTY_IDENTIFIER | ASTERISK | WS );";
        }
        public int specialStateTransition(int s) throws NoViableAltException {
        	int _s = s;
            switch ( s ) {
                    case 0 : 
                        int LA7_39 = input.LA(1);
                        s = -1;
                        if ( (LA7_39=='l') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == STRING_MODE || currentMode == ALIAS_MODE ))) {s = 64;}

                        else if ( ((LA7_39>='a' && LA7_39<='k')||(LA7_39>='m' && LA7_39<='z')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 23;}

                        else if ( ((LA7_39>='0' && LA7_39<='9')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 24;}

                        else if ( (LA7_39=='.') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE ))) {s = 25;}

                        else if ( (LA7_39=='_') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 26;}

                        else s = 45;

                        if ( s>=0 ) return s;
                        break;
                    case 1 : 
                        int LA7_6 = input.LA(1);
                        s = -1;
                        if ( (LA7_6=='e') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == STRING_MODE || currentMode == ALIAS_MODE ))) {s = 31;}

                        else if ( (LA7_6=='i') ) {s = 32;}

                        else if ( ((LA7_6>='a' && LA7_6<='d')||(LA7_6>='f' && LA7_6<='h')||(LA7_6>='j' && LA7_6<='z')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 23;}

                        else if ( ((LA7_6>='0' && LA7_6<='9')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 24;}

                        else if ( (LA7_6=='.') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE ))) {s = 25;}

                        else if ( (LA7_6=='_') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 26;}

                        else s = 22;

                        if ( s>=0 ) return s;
                        break;
                    case 2 : 
                        input.rewind();
                        s = -1;
                        if ( ( currentMode == STRING_MODE ) ) {s = 104;}

                        else if ( ( currentMode == ALIAS_MODE ) ) {s = 22;}

                        else if ( ( currentMode == CLASS_IDENTIFIER_MODE ) ) {s = 70;}

                        else if ( ( currentMode == PROPERTY_IDENTIFIER_MODE ) ) {s = 71;}

                        if ( s>=0 ) return s;
                        break;
                    case 3 : 
                        int LA7_0 = input.LA(1);
                        s = -1;
                        if ( (LA7_0=='s') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE || currentMode == STRING_MODE ))) {s = 1;}

                        else if ( (LA7_0=='f') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE || currentMode == STRING_MODE ))) {s = 2;}

                        else if ( (LA7_0=='w') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE || currentMode == STRING_MODE ))) {s = 3;}

                        else if ( (LA7_0==',') ) {s = 4;}

                        else if ( (LA7_0=='a') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE || currentMode == STRING_MODE ))) {s = 5;}

                        else if ( (LA7_0=='l') ) {s = 6;}

                        else if ( (LA7_0=='!'||(LA7_0>='<' && LA7_0<='>')) ) {s = 7;}

                        else if ( (LA7_0=='o') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == STRING_MODE || currentMode == ALIAS_MODE ))) {s = 8;}

                        else if ( (LA7_0=='i') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE || currentMode == STRING_MODE ))) {s = 9;}

                        else if ( (LA7_0=='n') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE || currentMode == STRING_MODE ))) {s = 10;}

                        else if ( (LA7_0=='r') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == STRING_MODE || currentMode == ALIAS_MODE ))) {s = 11;}

                        else if ( (LA7_0=='j') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == STRING_MODE || currentMode == ALIAS_MODE ))) {s = 12;}

                        else if ( (LA7_0=='b') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE || currentMode == STRING_MODE ))) {s = 13;}

                        else if ( (LA7_0=='d') ) {s = 14;}

                        else if ( (LA7_0=='c'||LA7_0=='e'||(LA7_0>='g' && LA7_0<='h')||LA7_0=='k'||LA7_0=='m'||(LA7_0>='p' && LA7_0<='q')||(LA7_0>='t' && LA7_0<='v')||(LA7_0>='x' && LA7_0<='z')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 15;}

                        else if ( (LA7_0=='(') ) {s = 16;}

                        else if ( (LA7_0==')') ) {s = 17;}

                        else if ( (LA7_0==':') ) {s = 18;}

                        else if ( (LA7_0=='*') ) {s = 19;}

                        else if ( ((LA7_0>='\t' && LA7_0<='\n')||(LA7_0>='\f' && LA7_0<='\r')||LA7_0==' ') ) {s = 20;}

                        if ( s>=0 ) return s;
                        break;
                    case 4 : 
                        int LA7_15 = input.LA(1);
                        s = -1;
                        if ( ((LA7_15>='a' && LA7_15<='z')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 23;}

                        else if ( ((LA7_15>='0' && LA7_15<='9')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 24;}

                        else if ( (LA7_15=='.') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE ))) {s = 25;}

                        else if ( (LA7_15=='_') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 26;}

                        else s = 22;

                        if ( s>=0 ) return s;
                        break;
                    case 5 : 
                        int LA7_37 = input.LA(1);
                        s = -1;
                        if ( ((LA7_37>='a' && LA7_37<='z')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 23;}

                        else if ( ((LA7_37>='0' && LA7_37<='9')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 24;}

                        else if ( (LA7_37=='.') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE ))) {s = 25;}

                        else if ( (LA7_37=='_') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 26;}

                        else s = 62;

                        if ( s>=0 ) return s;
                        break;
                    case 6 : 
                        int LA7_80 = input.LA(1);
                        s = -1;
                        if ( (LA7_80=='r') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE || currentMode == STRING_MODE ))) {s = 97;}

                        else if ( ((LA7_80>='a' && LA7_80<='q')||(LA7_80>='s' && LA7_80<='z')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 23;}

                        else if ( ((LA7_80>='0' && LA7_80<='9')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 24;}

                        else if ( (LA7_80=='.') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE ))) {s = 25;}

                        else if ( (LA7_80=='_') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 26;}

                        else s = 45;

                        if ( s>=0 ) return s;
                        break;
                    case 7 : 
                        int LA7_33 = input.LA(1);
                        s = -1;
                        if ( (LA7_33=='d') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == STRING_MODE || currentMode == ALIAS_MODE ))) {s = 57;}

                        else if ( ((LA7_33>='a' && LA7_33<='c')||(LA7_33>='e' && LA7_33<='z')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 23;}

                        else if ( ((LA7_33>='0' && LA7_33<='9')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 24;}

                        else if ( (LA7_33=='.') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE ))) {s = 25;}

                        else if ( (LA7_33=='_') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 26;}

                        else s = 58;

                        if ( s>=0 ) return s;
                        break;
                    case 8 : 
                        input.rewind();
                        s = -1;
                        if ( ( currentMode == ALIAS_MODE ) ) {s = 22;}

                        else if ( ( currentMode == STRING_MODE ) ) {s = 109;}

                        else if ( ( currentMode == CLASS_IDENTIFIER_MODE ) ) {s = 70;}

                        else if ( ( currentMode == PROPERTY_IDENTIFIER_MODE ) ) {s = 71;}

                        if ( s>=0 ) return s;
                        break;
                    case 9 : 
                        int LA7_10 = input.LA(1);
                        s = -1;
                        if ( (LA7_10=='o') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE || currentMode == STRING_MODE ))) {s = 38;}

                        else if ( (LA7_10=='u') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == STRING_MODE || currentMode == ALIAS_MODE ))) {s = 39;}

                        else if ( ((LA7_10>='a' && LA7_10<='n')||(LA7_10>='p' && LA7_10<='t')||(LA7_10>='v' && LA7_10<='z')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 23;}

                        else if ( ((LA7_10>='0' && LA7_10<='9')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 24;}

                        else if ( (LA7_10=='.') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE ))) {s = 25;}

                        else if ( (LA7_10=='_') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 26;}

                        else s = 22;

                        if ( s>=0 ) return s;
                        break;
                    case 10 : 
                        input.rewind();
                        s = -1;
                        if ( ( currentMode == ALIAS_MODE ) ) {s = 22;}

                        else if ( ( currentMode == STRING_MODE ) ) {s = 82;}

                        else if ( ( currentMode == CLASS_IDENTIFIER_MODE ) ) {s = 70;}

                        else if ( ( currentMode == PROPERTY_IDENTIFIER_MODE ) ) {s = 71;}

                        if ( s>=0 ) return s;
                        break;
                    case 11 : 
                        int LA7_87 = input.LA(1);
                        s = -1;
                        if ( ((LA7_87>='a' && LA7_87<='z')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 23;}

                        else if ( ((LA7_87>='0' && LA7_87<='9')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 24;}

                        else if ( (LA7_87=='.') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE ))) {s = 25;}

                        else if ( (LA7_87=='_') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 26;}

                        else s = 101;

                        if ( s>=0 ) return s;
                        break;
                    case 12 : 
                        int LA7_85 = input.LA(1);
                        s = -1;
                        if ( ((LA7_85>='a' && LA7_85<='z')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 23;}

                        else if ( ((LA7_85>='0' && LA7_85<='9')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 24;}

                        else if ( (LA7_85=='.') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE ))) {s = 25;}

                        else if ( (LA7_85=='_') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 26;}

                        else s = 99;

                        if ( s>=0 ) return s;
                        break;
                    case 13 : 
                        int LA7_11 = input.LA(1);
                        s = -1;
                        if ( (LA7_11=='i') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE || currentMode == STRING_MODE ))) {s = 40;}

                        else if ( ((LA7_11>='a' && LA7_11<='h')||(LA7_11>='j' && LA7_11<='z')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 23;}

                        else if ( ((LA7_11>='0' && LA7_11<='9')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 24;}

                        else if ( (LA7_11=='.') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE ))) {s = 25;}

                        else if ( (LA7_11=='_') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 26;}

                        else s = 22;

                        if ( s>=0 ) return s;
                        break;
                    case 14 : 
                        int LA7_48 = input.LA(1);
                        s = -1;
                        if ( ((LA7_48>='a' && LA7_48<='z')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE ))) {s = 47;}

                        else if ( ((LA7_48>='0' && LA7_48<='9')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE ))) {s = 48;}

                        else if ( (LA7_48=='.') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE ))) {s = 25;}

                        else if ( (LA7_48=='_') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE ))) {s = 49;}

                        else s = 46;

                        if ( s>=0 ) return s;
                        break;
                    case 15 : 
                        input.rewind();
                        s = -1;
                        if ( ( currentMode == ALIAS_MODE ) ) {s = 22;}

                        else if ( ( currentMode == STRING_MODE ) ) {s = 106;}

                        else if ( ( currentMode == CLASS_IDENTIFIER_MODE ) ) {s = 70;}

                        else if ( ( currentMode == PROPERTY_IDENTIFIER_MODE ) ) {s = 71;}

                        if ( s>=0 ) return s;
                        break;
                    case 16 : 
                        int LA7_27 = input.LA(1);
                        s = -1;
                        if ( (LA7_27=='o') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == STRING_MODE || currentMode == ALIAS_MODE ))) {s = 50;}

                        else if ( ((LA7_27>='a' && LA7_27<='n')||(LA7_27>='p' && LA7_27<='z')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 23;}

                        else if ( ((LA7_27>='0' && LA7_27<='9')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 24;}

                        else if ( (LA7_27=='.') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE ))) {s = 25;}

                        else if ( (LA7_27=='_') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 26;}

                        else s = 45;

                        if ( s>=0 ) return s;
                        break;
                    case 17 : 
                        int LA7_3 = input.LA(1);
                        s = -1;
                        if ( (LA7_3=='h') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE || currentMode == STRING_MODE ))) {s = 28;}

                        else if ( ((LA7_3>='a' && LA7_3<='g')||(LA7_3>='i' && LA7_3<='z')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 23;}

                        else if ( ((LA7_3>='0' && LA7_3<='9')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 24;}

                        else if ( (LA7_3=='.') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE ))) {s = 25;}

                        else if ( (LA7_3=='_') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 26;}

                        else s = 22;

                        if ( s>=0 ) return s;
                        break;
                    case 18 : 
                        int LA7_89 = input.LA(1);
                        s = -1;
                        if ( ((LA7_89>='a' && LA7_89<='z')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 23;}

                        else if ( ((LA7_89>='0' && LA7_89<='9')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 24;}

                        else if ( (LA7_89=='.') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE ))) {s = 25;}

                        else if ( (LA7_89=='_') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 26;}

                        else s = 102;

                        if ( s>=0 ) return s;
                        break;
                    case 19 : 
                        int LA7_90 = input.LA(1);
                        s = -1;
                        if ( (LA7_90=='t') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE || currentMode == STRING_MODE ))) {s = 103;}

                        else if ( ((LA7_90>='a' && LA7_90<='s')||(LA7_90>='u' && LA7_90<='z')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 23;}

                        else if ( ((LA7_90>='0' && LA7_90<='9')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 24;}

                        else if ( (LA7_90=='.') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE ))) {s = 25;}

                        else if ( (LA7_90=='_') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 26;}

                        else s = 45;

                        if ( s>=0 ) return s;
                        break;
                    case 20 : 
                        int LA7_69 = input.LA(1);
                        s = -1;
                        if ( (LA7_69=='c') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE || currentMode == STRING_MODE ))) {s = 90;}

                        else if ( ((LA7_69>='a' && LA7_69<='b')||(LA7_69>='d' && LA7_69<='z')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 23;}

                        else if ( ((LA7_69>='0' && LA7_69<='9')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 24;}

                        else if ( (LA7_69=='.') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE ))) {s = 25;}

                        else if ( (LA7_69=='_') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 26;}

                        else s = 45;

                        if ( s>=0 ) return s;
                        break;
                    case 21 : 
                        int LA7_72 = input.LA(1);
                        s = -1;
                        if ( ((LA7_72>='a' && LA7_72<='z')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 23;}

                        else if ( ((LA7_72>='0' && LA7_72<='9')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 24;}

                        else if ( (LA7_72=='.') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE ))) {s = 25;}

                        else if ( (LA7_72=='_') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 26;}

                        else s = 91;

                        if ( s>=0 ) return s;
                        break;
                    case 22 : 
                        int LA7_21 = input.LA(1);
                        s = -1;
                        if ( (LA7_21=='l') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == STRING_MODE || currentMode == ALIAS_MODE ))) {s = 44;}

                        else if ( ((LA7_21>='a' && LA7_21<='k')||(LA7_21>='m' && LA7_21<='z')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 23;}

                        else if ( ((LA7_21>='0' && LA7_21<='9')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 24;}

                        else if ( (LA7_21=='.') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE ))) {s = 25;}

                        else if ( (LA7_21=='_') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 26;}

                        else s = 45;

                        if ( s>=0 ) return s;
                        break;
                    case 23 : 
                        int LA7_49 = input.LA(1);
                        s = -1;
                        if ( ((LA7_49>='a' && LA7_49<='z')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE ))) {s = 47;}

                        else if ( ((LA7_49>='0' && LA7_49<='9')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE ))) {s = 48;}

                        else if ( (LA7_49=='.') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE ))) {s = 25;}

                        else if ( (LA7_49=='_') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE ))) {s = 49;}

                        else s = 46;

                        if ( s>=0 ) return s;
                        break;
                    case 24 : 
                        int LA7_34 = input.LA(1);
                        s = -1;
                        if ( (LA7_34=='t') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE || currentMode == STRING_MODE ))) {s = 59;}

                        else if ( ((LA7_34>='a' && LA7_34<='s')||(LA7_34>='u' && LA7_34<='z')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 23;}

                        else if ( ((LA7_34>='0' && LA7_34<='9')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 24;}

                        else if ( (LA7_34=='.') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE ))) {s = 25;}

                        else if ( (LA7_34=='_') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 26;}

                        else s = 45;

                        if ( s>=0 ) return s;
                        break;
                    case 25 : 
                        int LA7_9 = input.LA(1);
                        s = -1;
                        if ( (LA7_9=='n') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE || currentMode == STRING_MODE ))) {s = 36;}

                        else if ( (LA7_9=='s') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == STRING_MODE || currentMode == ALIAS_MODE ))) {s = 37;}

                        else if ( ((LA7_9>='a' && LA7_9<='m')||(LA7_9>='o' && LA7_9<='r')||(LA7_9>='t' && LA7_9<='z')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 23;}

                        else if ( ((LA7_9>='0' && LA7_9<='9')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 24;}

                        else if ( (LA7_9=='.') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE ))) {s = 25;}

                        else if ( (LA7_9=='_') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 26;}

                        else s = 22;

                        if ( s>=0 ) return s;
                        break;
                    case 26 : 
                        int LA7_59 = input.LA(1);
                        s = -1;
                        if ( (LA7_59=='e') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE || currentMode == STRING_MODE ))) {s = 80;}

                        else if ( ((LA7_59>='a' && LA7_59<='d')||(LA7_59>='f' && LA7_59<='z')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 23;}

                        else if ( ((LA7_59>='0' && LA7_59<='9')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 24;}

                        else if ( (LA7_59=='.') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE ))) {s = 25;}

                        else if ( (LA7_59=='_') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 26;}

                        else s = 45;

                        if ( s>=0 ) return s;
                        break;
                    case 27 : 
                        int LA7_25 = input.LA(1);
                        s = -1;
                        if ( ((LA7_25>='a' && LA7_25<='z')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE ))) {s = 47;}

                        else if ( ((LA7_25>='0' && LA7_25<='9')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE ))) {s = 48;}

                        else if ( (LA7_25=='.') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE ))) {s = 25;}

                        else if ( (LA7_25=='_') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE ))) {s = 49;}

                        else s = 46;

                        if ( s>=0 ) return s;
                        break;
                    case 28 : 
                        int LA7_47 = input.LA(1);
                        s = -1;
                        if ( ((LA7_47>='a' && LA7_47<='z')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE ))) {s = 47;}

                        else if ( ((LA7_47>='0' && LA7_47<='9')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE ))) {s = 48;}

                        else if ( (LA7_47=='.') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE ))) {s = 25;}

                        else if ( (LA7_47=='_') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE ))) {s = 49;}

                        else s = 46;

                        if ( s>=0 ) return s;
                        break;
                    case 29 : 
                        int LA7_50 = input.LA(1);
                        s = -1;
                        if ( (LA7_50=='m') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == STRING_MODE || currentMode == ALIAS_MODE ))) {s = 72;}

                        else if ( ((LA7_50>='a' && LA7_50<='l')||(LA7_50>='n' && LA7_50<='z')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 23;}

                        else if ( ((LA7_50>='0' && LA7_50<='9')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 24;}

                        else if ( (LA7_50=='.') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE ))) {s = 25;}

                        else if ( (LA7_50=='_') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 26;}

                        else s = 45;

                        if ( s>=0 ) return s;
                        break;
                    case 30 : 
                        int LA7_43 = input.LA(1);
                        s = -1;
                        if ( (LA7_43=='s') ) {s = 68;}

                        else if ( ((LA7_43>='a' && LA7_43<='r')||(LA7_43>='t' && LA7_43<='z')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 23;}

                        else if ( ((LA7_43>='0' && LA7_43<='9')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 24;}

                        else if ( (LA7_43=='.') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE ))) {s = 25;}

                        else if ( (LA7_43=='_') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 26;}

                        else s = 45;

                        if ( s>=0 ) return s;
                        break;
                    case 31 : 
                        int LA7_64 = input.LA(1);
                        s = -1;
                        if ( (LA7_64=='l') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE || currentMode == STRING_MODE ))) {s = 85;}

                        else if ( ((LA7_64>='a' && LA7_64<='k')||(LA7_64>='m' && LA7_64<='z')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 23;}

                        else if ( ((LA7_64>='0' && LA7_64<='9')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 24;}

                        else if ( (LA7_64=='.') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE ))) {s = 25;}

                        else if ( (LA7_64=='_') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 26;}

                        else s = 45;

                        if ( s>=0 ) return s;
                        break;
                    case 32 : 
                        int LA7_76 = input.LA(1);
                        s = -1;
                        if ( ((LA7_76>='a' && LA7_76<='z')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 23;}

                        else if ( ((LA7_76>='0' && LA7_76<='9')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 24;}

                        else if ( (LA7_76=='.') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE ))) {s = 25;}

                        else if ( (LA7_76=='_') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 26;}

                        else s = 94;

                        if ( s>=0 ) return s;
                        break;
                    case 33 : 
                        int LA7_73 = input.LA(1);
                        s = -1;
                        if ( (LA7_73=='e') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == STRING_MODE || currentMode == ALIAS_MODE ))) {s = 92;}

                        else if ( ((LA7_73>='a' && LA7_73<='d')||(LA7_73>='f' && LA7_73<='z')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 23;}

                        else if ( ((LA7_73>='0' && LA7_73<='9')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 24;}

                        else if ( (LA7_73=='.') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE ))) {s = 25;}

                        else if ( (LA7_73=='_') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 26;}

                        else s = 45;

                        if ( s>=0 ) return s;
                        break;
                    case 34 : 
                        int LA7_68 = input.LA(1);
                        s = -1;
                        if ( (LA7_68=='c') ) {s = 89;}

                        else if ( ((LA7_68>='a' && LA7_68<='b')||(LA7_68>='d' && LA7_68<='z')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 23;}

                        else if ( ((LA7_68>='0' && LA7_68<='9')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 24;}

                        else if ( (LA7_68=='.') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE ))) {s = 25;}

                        else if ( (LA7_68=='_') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 26;}

                        else s = 45;

                        if ( s>=0 ) return s;
                        break;
                    case 35 : 
                        input.rewind();
                        s = -1;
                        if ( ( currentMode == ALIAS_MODE ) ) {s = 22;}

                        else if ( ( currentMode == STRING_MODE ) ) {s = 81;}

                        else if ( ( currentMode == CLASS_IDENTIFIER_MODE ) ) {s = 70;}

                        else if ( ( currentMode == PROPERTY_IDENTIFIER_MODE ) ) {s = 71;}

                        if ( s>=0 ) return s;
                        break;
                    case 36 : 
                        int LA7_12 = input.LA(1);
                        s = -1;
                        if ( (LA7_12=='o') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == STRING_MODE || currentMode == ALIAS_MODE ))) {s = 41;}

                        else if ( ((LA7_12>='a' && LA7_12<='n')||(LA7_12>='p' && LA7_12<='z')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 23;}

                        else if ( ((LA7_12>='0' && LA7_12<='9')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 24;}

                        else if ( (LA7_12=='.') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE ))) {s = 25;}

                        else if ( (LA7_12=='_') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 26;}

                        else s = 22;

                        if ( s>=0 ) return s;
                        break;
                    case 37 : 
                        int LA7_1 = input.LA(1);
                        s = -1;
                        if ( (LA7_1=='e') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE || currentMode == STRING_MODE ))) {s = 21;}

                        else if ( ((LA7_1>='a' && LA7_1<='d')||(LA7_1>='f' && LA7_1<='z')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 23;}

                        else if ( ((LA7_1>='0' && LA7_1<='9')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 24;}

                        else if ( (LA7_1=='.') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE ))) {s = 25;}

                        else if ( (LA7_1=='_') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 26;}

                        else s = 22;

                        if ( s>=0 ) return s;
                        break;
                    case 38 : 
                        int LA7_100 = input.LA(1);
                        s = -1;
                        if ( ((LA7_100>='a' && LA7_100<='z')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 23;}

                        else if ( ((LA7_100>='0' && LA7_100<='9')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 24;}

                        else if ( (LA7_100=='.') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE ))) {s = 25;}

                        else if ( (LA7_100=='_') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 26;}

                        else s = 110;

                        if ( s>=0 ) return s;
                        break;
                    case 39 : 
                        input.rewind();
                        s = -1;
                        if ( ( currentMode == ALIAS_MODE ) ) {s = 22;}

                        else if ( ( currentMode == STRING_MODE ) ) {s = 115;}

                        else if ( ( currentMode == CLASS_IDENTIFIER_MODE ) ) {s = 70;}

                        else if ( ( currentMode == PROPERTY_IDENTIFIER_MODE ) ) {s = 71;}

                        if ( s>=0 ) return s;
                        break;
                    case 40 : 
                        input.rewind();
                        s = -1;
                        if ( ( currentMode == ALIAS_MODE ) ) {s = 22;}

                        else if ( ( currentMode == STRING_MODE ) ) {s = 88;}

                        else if ( ( currentMode == CLASS_IDENTIFIER_MODE ) ) {s = 70;}

                        else if ( ( currentMode == PROPERTY_IDENTIFIER_MODE ) ) {s = 71;}

                        if ( s>=0 ) return s;
                        break;
                    case 41 : 
                        int LA7_66 = input.LA(1);
                        s = -1;
                        if ( (LA7_66=='n') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE || currentMode == STRING_MODE ))) {s = 87;}

                        else if ( ((LA7_66>='a' && LA7_66<='m')||(LA7_66>='o' && LA7_66<='z')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 23;}

                        else if ( ((LA7_66>='0' && LA7_66<='9')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 24;}

                        else if ( (LA7_66=='.') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE ))) {s = 25;}

                        else if ( (LA7_66=='_') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 26;}

                        else s = 45;

                        if ( s>=0 ) return s;
                        break;
                    case 42 : 
                        int LA7_38 = input.LA(1);
                        s = -1;
                        if ( (LA7_38=='t') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == STRING_MODE || currentMode == ALIAS_MODE ))) {s = 63;}

                        else if ( ((LA7_38>='a' && LA7_38<='s')||(LA7_38>='u' && LA7_38<='z')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 23;}

                        else if ( ((LA7_38>='0' && LA7_38<='9')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 24;}

                        else if ( (LA7_38=='.') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE ))) {s = 25;}

                        else if ( (LA7_38=='_') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 26;}

                        else s = 45;

                        if ( s>=0 ) return s;
                        break;
                    case 43 : 
                        input.rewind();
                        s = -1;
                        if ( ( currentMode == ALIAS_MODE ) ) {s = 22;}

                        else if ( (!(( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) ) {s = 7;}

                        else if ( ( currentMode == CLASS_IDENTIFIER_MODE ) ) {s = 70;}

                        else if ( ( currentMode == PROPERTY_IDENTIFIER_MODE ) ) {s = 71;}

                        if ( s>=0 ) return s;
                        break;
                    case 44 : 
                        int LA7_63 = input.LA(1);
                        s = -1;
                        if ( ((LA7_63>='a' && LA7_63<='z')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 23;}

                        else if ( ((LA7_63>='0' && LA7_63<='9')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 24;}

                        else if ( (LA7_63=='.') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE ))) {s = 25;}

                        else if ( (LA7_63=='_') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 26;}

                        else s = 84;

                        if ( s>=0 ) return s;
                        break;
                    case 45 : 
                        int LA7_2 = input.LA(1);
                        s = -1;
                        if ( (LA7_2=='r') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE || currentMode == STRING_MODE ))) {s = 27;}

                        else if ( ((LA7_2>='a' && LA7_2<='q')||(LA7_2>='s' && LA7_2<='z')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 23;}

                        else if ( ((LA7_2>='0' && LA7_2<='9')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 24;}

                        else if ( (LA7_2=='.') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE ))) {s = 25;}

                        else if ( (LA7_2=='_') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 26;}

                        else s = 22;

                        if ( s>=0 ) return s;
                        break;
                    case 46 : 
                        int LA7_77 = input.LA(1);
                        s = -1;
                        if ( ((LA7_77>='a' && LA7_77<='z')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 23;}

                        else if ( ((LA7_77>='0' && LA7_77<='9')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 24;}

                        else if ( (LA7_77=='.') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE ))) {s = 25;}

                        else if ( (LA7_77=='_') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 26;}

                        else s = 95;

                        if ( s>=0 ) return s;
                        break;
                    case 47 : 
                        input.rewind();
                        s = -1;
                        if ( ( currentMode == ALIAS_MODE ) ) {s = 22;}

                        else if ( ( currentMode == STRING_MODE ) ) {s = 79;}

                        else if ( ( currentMode == CLASS_IDENTIFIER_MODE ) ) {s = 70;}

                        else if ( ( currentMode == PROPERTY_IDENTIFIER_MODE ) ) {s = 71;}

                        if ( s>=0 ) return s;
                        break;
                    case 48 : 
                        int LA7_42 = input.LA(1);
                        s = -1;
                        if ( ((LA7_42>='a' && LA7_42<='z')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 23;}

                        else if ( ((LA7_42>='0' && LA7_42<='9')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 24;}

                        else if ( (LA7_42=='.') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE ))) {s = 25;}

                        else if ( (LA7_42=='_') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 26;}

                        else s = 67;

                        if ( s>=0 ) return s;
                        break;
                    case 49 : 
                        int LA7_5 = input.LA(1);
                        s = -1;
                        if ( (LA7_5=='s') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == STRING_MODE || currentMode == ALIAS_MODE ))) {s = 29;}

                        else if ( (LA7_5=='n') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == STRING_MODE || currentMode == ALIAS_MODE ))) {s = 30;}

                        else if ( ((LA7_5>='a' && LA7_5<='m')||(LA7_5>='o' && LA7_5<='r')||(LA7_5>='t' && LA7_5<='z')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 23;}

                        else if ( ((LA7_5>='0' && LA7_5<='9')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 24;}

                        else if ( (LA7_5=='.') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE ))) {s = 25;}

                        else if ( (LA7_5=='_') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 26;}

                        else s = 22;

                        if ( s>=0 ) return s;
                        break;
                    case 50 : 
                        int LA7_92 = input.LA(1);
                        s = -1;
                        if ( ((LA7_92>='a' && LA7_92<='z')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 23;}

                        else if ( ((LA7_92>='0' && LA7_92<='9')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 24;}

                        else if ( (LA7_92=='.') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE ))) {s = 25;}

                        else if ( (LA7_92=='_') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 26;}

                        else s = 105;

                        if ( s>=0 ) return s;
                        break;
                    case 51 : 
                        int LA7_40 = input.LA(1);
                        s = -1;
                        if ( (LA7_40=='g') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == STRING_MODE || currentMode == ALIAS_MODE ))) {s = 65;}

                        else if ( ((LA7_40>='a' && LA7_40<='f')||(LA7_40>='h' && LA7_40<='z')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 23;}

                        else if ( ((LA7_40>='0' && LA7_40<='9')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 24;}

                        else if ( (LA7_40=='.') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE ))) {s = 25;}

                        else if ( (LA7_40=='_') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 26;}

                        else s = 45;

                        if ( s>=0 ) return s;
                        break;
                    case 52 : 
                        int LA7_41 = input.LA(1);
                        s = -1;
                        if ( (LA7_41=='i') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE || currentMode == STRING_MODE ))) {s = 66;}

                        else if ( ((LA7_41>='a' && LA7_41<='h')||(LA7_41>='j' && LA7_41<='z')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 23;}

                        else if ( ((LA7_41>='0' && LA7_41<='9')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 24;}

                        else if ( (LA7_41=='.') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE ))) {s = 25;}

                        else if ( (LA7_41=='_') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 26;}

                        else s = 45;

                        if ( s>=0 ) return s;
                        break;
                    case 53 : 
                        input.rewind();
                        s = -1;
                        if ( ( currentMode == ALIAS_MODE ) ) {s = 22;}

                        else if ( ( currentMode == CLASS_IDENTIFIER_MODE ) ) {s = 70;}

                        else if ( ( currentMode == PROPERTY_IDENTIFIER_MODE ) ) {s = 71;}

                        if ( s>=0 ) return s;
                        break;
                    case 54 : 
                        int LA7_26 = input.LA(1);
                        s = -1;
                        if ( ((LA7_26>='a' && LA7_26<='z')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 23;}

                        else if ( ((LA7_26>='0' && LA7_26<='9')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 24;}

                        else if ( (LA7_26=='_') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 26;}

                        else if ( (LA7_26=='.') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE ))) {s = 25;}

                        else s = 45;

                        if ( s>=0 ) return s;
                        break;
                    case 55 : 
                        int LA7_28 = input.LA(1);
                        s = -1;
                        if ( (LA7_28=='e') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE || currentMode == STRING_MODE ))) {s = 51;}

                        else if ( ((LA7_28>='a' && LA7_28<='d')||(LA7_28>='f' && LA7_28<='z')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 23;}

                        else if ( ((LA7_28>='0' && LA7_28<='9')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 24;}

                        else if ( (LA7_28=='.') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE ))) {s = 25;}

                        else if ( (LA7_28=='_') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 26;}

                        else s = 45;

                        if ( s>=0 ) return s;
                        break;
                    case 56 : 
                        int LA7_24 = input.LA(1);
                        s = -1;
                        if ( ((LA7_24>='a' && LA7_24<='z')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 23;}

                        else if ( ((LA7_24>='0' && LA7_24<='9')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 24;}

                        else if ( (LA7_24=='_') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 26;}

                        else if ( (LA7_24=='.') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE ))) {s = 25;}

                        else s = 45;

                        if ( s>=0 ) return s;
                        break;
                    case 57 : 
                        int LA7_103 = input.LA(1);
                        s = -1;
                        if ( ((LA7_103>='a' && LA7_103<='z')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 23;}

                        else if ( ((LA7_103>='0' && LA7_103<='9')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 24;}

                        else if ( (LA7_103=='.') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE ))) {s = 25;}

                        else if ( (LA7_103=='_') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 26;}

                        else s = 113;

                        if ( s>=0 ) return s;
                        break;
                    case 58 : 
                        int LA7_44 = input.LA(1);
                        s = -1;
                        if ( (LA7_44=='e') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE || currentMode == STRING_MODE ))) {s = 69;}

                        else if ( ((LA7_44>='a' && LA7_44<='d')||(LA7_44>='f' && LA7_44<='z')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 23;}

                        else if ( ((LA7_44>='0' && LA7_44<='9')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 24;}

                        else if ( (LA7_44=='.') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE ))) {s = 25;}

                        else if ( (LA7_44=='_') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 26;}

                        else s = 45;

                        if ( s>=0 ) return s;
                        break;
                    case 59 : 
                        input.rewind();
                        s = -1;
                        if ( ( currentMode == ALIAS_MODE ) ) {s = 22;}

                        else if ( (!(( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) ) {s = 112;}

                        else if ( ( currentMode == CLASS_IDENTIFIER_MODE ) ) {s = 70;}

                        else if ( ( currentMode == PROPERTY_IDENTIFIER_MODE ) ) {s = 71;}

                        if ( s>=0 ) return s;
                        break;
                    case 60 : 
                        input.rewind();
                        s = -1;
                        if ( ( currentMode == ALIAS_MODE ) ) {s = 22;}

                        else if ( ( currentMode == STRING_MODE ) ) {s = 93;}

                        else if ( ( currentMode == CLASS_IDENTIFIER_MODE ) ) {s = 70;}

                        else if ( ( currentMode == PROPERTY_IDENTIFIER_MODE ) ) {s = 71;}

                        if ( s>=0 ) return s;
                        break;
                    case 61 : 
                        int LA7_13 = input.LA(1);
                        s = -1;
                        if ( (LA7_13=='y') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE || currentMode == STRING_MODE ))) {s = 42;}

                        else if ( ((LA7_13>='a' && LA7_13<='x')||LA7_13=='z') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 23;}

                        else if ( ((LA7_13>='0' && LA7_13<='9')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 24;}

                        else if ( (LA7_13=='.') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE ))) {s = 25;}

                        else if ( (LA7_13=='_') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 26;}

                        else s = 22;

                        if ( s>=0 ) return s;
                        break;
                    case 62 : 
                        int LA7_97 = input.LA(1);
                        s = -1;
                        if ( ((LA7_97>='a' && LA7_97<='z')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 23;}

                        else if ( ((LA7_97>='0' && LA7_97<='9')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 24;}

                        else if ( (LA7_97=='.') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE ))) {s = 25;}

                        else if ( (LA7_97=='_') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 26;}

                        else s = 108;

                        if ( s>=0 ) return s;
                        break;
                    case 63 : 
                        int LA7_65 = input.LA(1);
                        s = -1;
                        if ( (LA7_65=='h') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == STRING_MODE || currentMode == ALIAS_MODE ))) {s = 86;}

                        else if ( ((LA7_65>='a' && LA7_65<='g')||(LA7_65>='i' && LA7_65<='z')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 23;}

                        else if ( ((LA7_65>='0' && LA7_65<='9')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 24;}

                        else if ( (LA7_65=='.') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE ))) {s = 25;}

                        else if ( (LA7_65=='_') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 26;}

                        else s = 45;

                        if ( s>=0 ) return s;
                        break;
                    case 64 : 
                        int LA7_31 = input.LA(1);
                        s = -1;
                        if ( (LA7_31=='f') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == STRING_MODE || currentMode == ALIAS_MODE ))) {s = 55;}

                        else if ( ((LA7_31>='a' && LA7_31<='e')||(LA7_31>='g' && LA7_31<='z')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 23;}

                        else if ( ((LA7_31>='0' && LA7_31<='9')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 24;}

                        else if ( (LA7_31=='.') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE ))) {s = 25;}

                        else if ( (LA7_31=='_') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 26;}

                        else s = 45;

                        if ( s>=0 ) return s;
                        break;
                    case 65 : 
                        int LA7_51 = input.LA(1);
                        s = -1;
                        if ( (LA7_51=='r') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == STRING_MODE || currentMode == ALIAS_MODE ))) {s = 73;}

                        else if ( ((LA7_51>='a' && LA7_51<='q')||(LA7_51>='s' && LA7_51<='z')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 23;}

                        else if ( ((LA7_51>='0' && LA7_51<='9')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 24;}

                        else if ( (LA7_51=='.') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE ))) {s = 25;}

                        else if ( (LA7_51=='_') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 26;}

                        else s = 45;

                        if ( s>=0 ) return s;
                        break;
                    case 66 : 
                        int LA7_30 = input.LA(1);
                        s = -1;
                        if ( (LA7_30=='d') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == STRING_MODE || currentMode == ALIAS_MODE ))) {s = 54;}

                        else if ( ((LA7_30>='a' && LA7_30<='c')||(LA7_30>='e' && LA7_30<='z')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 23;}

                        else if ( ((LA7_30>='0' && LA7_30<='9')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 24;}

                        else if ( (LA7_30=='.') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE ))) {s = 25;}

                        else if ( (LA7_30=='_') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 26;}

                        else s = 45;

                        if ( s>=0 ) return s;
                        break;
                    case 67 : 
                        input.rewind();
                        s = -1;
                        if ( ( currentMode == ALIAS_MODE ) ) {s = 22;}

                        else if ( ( currentMode == STRING_MODE ) ) {s = 98;}

                        else if ( ( currentMode == CLASS_IDENTIFIER_MODE ) ) {s = 70;}

                        else if ( ( currentMode == PROPERTY_IDENTIFIER_MODE ) ) {s = 71;}

                        if ( s>=0 ) return s;
                        break;
                    case 68 : 
                        int LA7_8 = input.LA(1);
                        s = -1;
                        if ( (LA7_8=='r') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE || currentMode == STRING_MODE ))) {s = 33;}

                        else if ( (LA7_8=='u') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == STRING_MODE || currentMode == ALIAS_MODE ))) {s = 34;}

                        else if ( (LA7_8=='n') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == STRING_MODE || currentMode == ALIAS_MODE ))) {s = 35;}

                        else if ( ((LA7_8>='a' && LA7_8<='m')||(LA7_8>='o' && LA7_8<='q')||(LA7_8>='s' && LA7_8<='t')||(LA7_8>='v' && LA7_8<='z')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 23;}

                        else if ( ((LA7_8>='0' && LA7_8<='9')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 24;}

                        else if ( (LA7_8=='.') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE ))) {s = 25;}

                        else if ( (LA7_8=='_') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 26;}

                        else s = 22;

                        if ( s>=0 ) return s;
                        break;
                    case 69 : 
                        int LA7_23 = input.LA(1);
                        s = -1;
                        if ( ((LA7_23>='a' && LA7_23<='z')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 23;}

                        else if ( ((LA7_23>='0' && LA7_23<='9')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 24;}

                        else if ( (LA7_23=='.') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE ))) {s = 25;}

                        else if ( (LA7_23=='_') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 26;}

                        else s = 45;

                        if ( s>=0 ) return s;
                        break;
                    case 70 : 
                        int LA7_57 = input.LA(1);
                        s = -1;
                        if ( (LA7_57=='e') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == STRING_MODE || currentMode == ALIAS_MODE ))) {s = 78;}

                        else if ( ((LA7_57>='a' && LA7_57<='d')||(LA7_57>='f' && LA7_57<='z')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 23;}

                        else if ( ((LA7_57>='0' && LA7_57<='9')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 24;}

                        else if ( (LA7_57=='.') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE ))) {s = 25;}

                        else if ( (LA7_57=='_') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 26;}

                        else s = 45;

                        if ( s>=0 ) return s;
                        break;
                    case 71 : 
                        int LA7_36 = input.LA(1);
                        s = -1;
                        if ( ((LA7_36>='a' && LA7_36<='z')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 23;}

                        else if ( ((LA7_36>='0' && LA7_36<='9')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 24;}

                        else if ( (LA7_36=='.') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE ))) {s = 25;}

                        else if ( (LA7_36=='_') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 26;}

                        else s = 61;

                        if ( s>=0 ) return s;
                        break;
                    case 72 : 
                        int LA7_29 = input.LA(1);
                        s = -1;
                        if ( (LA7_29=='c') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE || currentMode == STRING_MODE ))) {s = 52;}

                        else if ( ((LA7_29>='a' && LA7_29<='b')||(LA7_29>='d' && LA7_29<='z')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 23;}

                        else if ( ((LA7_29>='0' && LA7_29<='9')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 24;}

                        else if ( (LA7_29=='.') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE ))) {s = 25;}

                        else if ( (LA7_29=='_') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 26;}

                        else s = 53;

                        if ( s>=0 ) return s;
                        break;
                    case 73 : 
                        input.rewind();
                        s = -1;
                        if ( ( currentMode == STRING_MODE ) ) {s = 75;}

                        else if ( ( currentMode == ALIAS_MODE ) ) {s = 22;}

                        else if ( ( currentMode == CLASS_IDENTIFIER_MODE ) ) {s = 70;}

                        else if ( ( currentMode == PROPERTY_IDENTIFIER_MODE ) ) {s = 71;}

                        if ( s>=0 ) return s;
                        break;
                    case 74 : 
                        input.rewind();
                        s = -1;
                        if ( ( currentMode == ALIAS_MODE ) ) {s = 22;}

                        else if ( ( currentMode == STRING_MODE ) ) {s = 116;}

                        else if ( ( currentMode == CLASS_IDENTIFIER_MODE ) ) {s = 70;}

                        else if ( ( currentMode == PROPERTY_IDENTIFIER_MODE ) ) {s = 71;}

                        if ( s>=0 ) return s;
                        break;
                    case 75 : 
                        int LA7_54 = input.LA(1);
                        s = -1;
                        if ( ((LA7_54>='a' && LA7_54<='z')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 23;}

                        else if ( ((LA7_54>='0' && LA7_54<='9')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 24;}

                        else if ( (LA7_54=='.') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE ))) {s = 25;}

                        else if ( (LA7_54=='_') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 26;}

                        else s = 58;

                        if ( s>=0 ) return s;
                        break;
                    case 76 : 
                        int LA7_52 = input.LA(1);
                        s = -1;
                        if ( ((LA7_52>='a' && LA7_52<='z')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 23;}

                        else if ( ((LA7_52>='0' && LA7_52<='9')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 24;}

                        else if ( (LA7_52=='.') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE ))) {s = 25;}

                        else if ( (LA7_52=='_') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 26;}

                        else s = 74;

                        if ( s>=0 ) return s;
                        break;
                    case 77 : 
                        input.rewind();
                        s = -1;
                        if ( ( currentMode == ALIAS_MODE ) ) {s = 22;}

                        else if ( ( currentMode == STRING_MODE ) ) {s = 83;}

                        else if ( ( currentMode == CLASS_IDENTIFIER_MODE ) ) {s = 70;}

                        else if ( ( currentMode == PROPERTY_IDENTIFIER_MODE ) ) {s = 71;}

                        if ( s>=0 ) return s;
                        break;
                    case 78 : 
                        input.rewind();
                        s = -1;
                        if ( ( currentMode == ALIAS_MODE ) ) {s = 22;}

                        else if ( ( currentMode == STRING_MODE ) ) {s = 117;}

                        else if ( ( currentMode == CLASS_IDENTIFIER_MODE ) ) {s = 70;}

                        else if ( ( currentMode == PROPERTY_IDENTIFIER_MODE ) ) {s = 71;}

                        if ( s>=0 ) return s;
                        break;
                    case 79 : 
                        int LA7_32 = input.LA(1);
                        s = -1;
                        if ( (LA7_32=='k') ) {s = 56;}

                        else if ( ((LA7_32>='a' && LA7_32<='j')||(LA7_32>='l' && LA7_32<='z')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 23;}

                        else if ( ((LA7_32>='0' && LA7_32<='9')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 24;}

                        else if ( (LA7_32=='.') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE ))) {s = 25;}

                        else if ( (LA7_32=='_') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 26;}

                        else s = 45;

                        if ( s>=0 ) return s;
                        break;
                    case 80 : 
                        int LA7_55 = input.LA(1);
                        s = -1;
                        if ( (LA7_55=='t') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE || currentMode == STRING_MODE ))) {s = 76;}

                        else if ( ((LA7_55>='a' && LA7_55<='s')||(LA7_55>='u' && LA7_55<='z')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 23;}

                        else if ( ((LA7_55>='0' && LA7_55<='9')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 24;}

                        else if ( (LA7_55=='.') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE ))) {s = 25;}

                        else if ( (LA7_55=='_') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 26;}

                        else s = 45;

                        if ( s>=0 ) return s;
                        break;
                    case 81 : 
                        int LA7_14 = input.LA(1);
                        s = -1;
                        if ( (LA7_14=='e') ) {s = 43;}

                        else if ( ((LA7_14>='a' && LA7_14<='d')||(LA7_14>='f' && LA7_14<='z')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 23;}

                        else if ( ((LA7_14>='0' && LA7_14<='9')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 24;}

                        else if ( (LA7_14=='.') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE ))) {s = 25;}

                        else if ( (LA7_14=='_') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 26;}

                        else s = 22;

                        if ( s>=0 ) return s;
                        break;
                    case 82 : 
                        int LA7_56 = input.LA(1);
                        s = -1;
                        if ( (LA7_56=='e') ) {s = 77;}

                        else if ( ((LA7_56>='a' && LA7_56<='d')||(LA7_56>='f' && LA7_56<='z')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 23;}

                        else if ( ((LA7_56>='0' && LA7_56<='9')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 24;}

                        else if ( (LA7_56=='.') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE ))) {s = 25;}

                        else if ( (LA7_56=='_') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 26;}

                        else s = 45;

                        if ( s>=0 ) return s;
                        break;
                    case 83 : 
                        input.rewind();
                        s = -1;
                        if ( ( currentMode == STRING_MODE ) ) {s = 118;}

                        else if ( ( currentMode == ALIAS_MODE ) ) {s = 22;}

                        else if ( ( currentMode == CLASS_IDENTIFIER_MODE ) ) {s = 70;}

                        else if ( ( currentMode == PROPERTY_IDENTIFIER_MODE ) ) {s = 71;}

                        if ( s>=0 ) return s;
                        break;
                    case 84 : 
                        input.rewind();
                        s = -1;
                        if ( ( currentMode == ALIAS_MODE ) ) {s = 22;}

                        else if ( ( currentMode == STRING_MODE ) ) {s = 111;}

                        else if ( ( currentMode == CLASS_IDENTIFIER_MODE ) ) {s = 70;}

                        else if ( ( currentMode == PROPERTY_IDENTIFIER_MODE ) ) {s = 71;}

                        if ( s>=0 ) return s;
                        break;
                    case 85 : 
                        int LA7_86 = input.LA(1);
                        s = -1;
                        if ( (LA7_86=='t') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == STRING_MODE || currentMode == ALIAS_MODE ))) {s = 100;}

                        else if ( ((LA7_86>='a' && LA7_86<='s')||(LA7_86>='u' && LA7_86<='z')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 23;}

                        else if ( ((LA7_86>='0' && LA7_86<='9')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 24;}

                        else if ( (LA7_86=='.') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE ))) {s = 25;}

                        else if ( (LA7_86=='_') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 26;}

                        else s = 45;

                        if ( s>=0 ) return s;
                        break;
                    case 86 : 
                        input.rewind();
                        s = -1;
                        if ( ( currentMode == CLASS_IDENTIFIER_MODE ) ) {s = 70;}

                        else if ( ( currentMode == PROPERTY_IDENTIFIER_MODE ) ) {s = 71;}

                        if ( s>=0 ) return s;
                        break;
                    case 87 : 
                        int LA7_35 = input.LA(1);
                        s = -1;
                        if ( ((LA7_35>='a' && LA7_35<='z')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 23;}

                        else if ( ((LA7_35>='0' && LA7_35<='9')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 24;}

                        else if ( (LA7_35=='.') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE ))) {s = 25;}

                        else if ( (LA7_35=='_') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 26;}

                        else s = 60;

                        if ( s>=0 ) return s;
                        break;
                    case 88 : 
                        int LA7_78 = input.LA(1);
                        s = -1;
                        if ( (LA7_78=='r') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE || currentMode == STRING_MODE ))) {s = 96;}

                        else if ( ((LA7_78>='a' && LA7_78<='q')||(LA7_78>='s' && LA7_78<='z')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 23;}

                        else if ( ((LA7_78>='0' && LA7_78<='9')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 24;}

                        else if ( (LA7_78=='.') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE ))) {s = 25;}

                        else if ( (LA7_78=='_') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 26;}

                        else s = 45;

                        if ( s>=0 ) return s;
                        break;
                    case 89 : 
                        input.rewind();
                        s = -1;
                        if ( ( currentMode == STRING_MODE ) ) {s = 114;}

                        else if ( ( currentMode == ALIAS_MODE ) ) {s = 22;}

                        else if ( ( currentMode == CLASS_IDENTIFIER_MODE ) ) {s = 70;}

                        else if ( ( currentMode == PROPERTY_IDENTIFIER_MODE ) ) {s = 71;}

                        if ( s>=0 ) return s;
                        break;
                    case 90 : 
                        int LA7_96 = input.LA(1);
                        s = -1;
                        if ( ((LA7_96>='a' && LA7_96<='z')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 23;}

                        else if ( ((LA7_96>='0' && LA7_96<='9')) && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 24;}

                        else if ( (LA7_96=='.') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE ))) {s = 25;}

                        else if ( (LA7_96=='_') && (( currentMode == PROPERTY_IDENTIFIER_MODE || currentMode == CLASS_IDENTIFIER_MODE || currentMode == ALIAS_MODE ))) {s = 26;}

                        else s = 107;

                        if ( s>=0 ) return s;
                        break;
            }
            NoViableAltException nvae =
                new NoViableAltException(getDescription(), 7, _s, input);
            error(nvae);
            throw nvae;
        }
    }
 

}