import org.antlr.runtime.*;
import org.antlr.runtime.tree.*;
import com.compoundtheory.antlr.*;

public class Test
{

	/**
	 * @param args
	 */
	public static void main(String[] args)
	{
		String tql;
		
		tql = "SeleCt Email.emailName, Email.emailFrom frOm emails.Email as Email, user.User whEre Email.emailName = :name";
		test(tql);
		
		tql = "select emails.Email.emailName from emails.Email where (emails.Email.emailName = :name)";
		test(tql);
		
		tql = "select emails.Email.emailName, emails.Email.emailFrom from emails.Email where emails.Email.emailName = :name and emails.Email.emailxyze = :xyz ";
		test(tql);

		tql = "select emails.Email.emailName, emails.Email.emailFrom from emails.Email where emails.Email.emailName = :name and emails.Email.emailxyze = :xyz or (emails.Email.emailName != :notname)";
		test(tql);
		
		tql = "from emails.Email where emails.Email.emailName = :name and emails.Email.emailxyze = :xyz or (emails.Email.emailName != :notname and (emails.Email.emailiii != :iiinotname))";
		test(tql);
		
		tql = "select emails.Email.emailName from emails.Email where (emails.Email.emailName IS NOT NULL)";
		test(tql);
		
		tql = "select emails.Email.emailName from emails.Email where (emails.Email.emailName IS NOT NULL) AND (emails.Email.emailTTT IS NULL) OR (emails.Email.emailxxx >= :fred)";
		test(tql);	
		
		tql = "select emails.Email.emailName from emails.Email";
		test(tql);
		
		tql = "from emails.Email";
		test(tql);
		
		tql = "SeleCt Email.emailName, Email.emailFrom frOm emails.Email as Email whEre Email.emailName = :name";
		test(tql);		
	}
	
	private static void test(String tql)
	{
		try
		{
				System.out.println(tql);
				CharStream input = new ANTLRNoCaseStringStream(tql);
		        TqlLexer lexer = new TqlLexer(input);
		        //System.out.println("** 1");
		        CommonTokenStream tokens = new  CommonTokenStream(lexer);
		        //System.out.println("** 2");
		        TqlParser parser = new TqlParser(tokens);
		        //System.out.println("** 3");
		        TqlParser.selectStatement_return root = parser.selectStatement();
		        //System.out.println("** 4");
		        System.out.println("tree="+((Tree)root.getTree()).toStringTree());
		}
		catch(Throwable t)
	    {
	        System.out.println("Exception: "+t.getMessage());
	        t.printStackTrace();
	    }
		
	}
	
	private static void tokenTest(String tql)
	{
	    try 
	    {
	    	CharStream input = new ANTLRStringStream(tql);
	        TqlLexer lexer = new TqlLexer(input);
	        Token token;
	        while ((token = lexer.nextToken())!=Token.EOF_TOKEN) 
	        {
	        	System.out.println("Token: [" + token.getType() + "]" + token.getText() );
	        }
	    } 
	    catch(Throwable t) 
	    {
	        System.out.println("Exception: "+t);
	        t.printStackTrace();
	    }
	}

}
