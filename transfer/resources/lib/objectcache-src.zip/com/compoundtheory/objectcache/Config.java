package com.compoundtheory.objectcache;

/**
 * A Cache configuration for a specific class
 * @author Mark Mandel
 *
 */
public class Config
{
	//cache values
	public static final int UNLIMITED_OBJECTS = 0;
	public static final int UNLIMITED_SECONDS = 0;
	public static final int NONE_TIMEOUT = 0;
	
	//scope values - not used here, but used in CF land.
	public static final String SCOPE_NONE = "none";
	public static final String SCOPE_SESSION = "session";
	public static final String SCOPE_TRANSACTION = "transaction";
	public static final String SCOPE_APPLICATION = "application";
	public static final String SCOPE_REQUEST = "request";
	public static final String SCOPE_SERVER = "server";
	public static final String SCOPE_INSTANCE = "instance";
	
	private int maxObjects;
	private int secondsPersisted;
	private int secondsAccessedTimeout; 
	
	private String scope;
	
	public Config()
	throws InvalidScopeException
	{
		this(UNLIMITED_OBJECTS, UNLIMITED_SECONDS, NONE_TIMEOUT, SCOPE_INSTANCE);	
	}
	
	/**
	 * Constructor
	 * @param maxObjects maximum number of objects you can have.
	 * @param secondsPersisted maximum number of seconds persisted.
	 */
	public Config(int maxObjects, int secondsPersisted, int secondsAccessedTimeout)
	throws InvalidScopeException
	{
		this(maxObjects, secondsPersisted, secondsAccessedTimeout, SCOPE_INSTANCE);
	}
	
	public Config(int maxObjects, int secondsPersisted, int secondsAccessedTimeout, String scope)
	throws InvalidScopeException
	{
		setMaxObjects(maxObjects);
		setSecondsPersisted(secondsPersisted);
		setSecondsAccessedTimeout(secondsAccessedTimeout);

		//make lower case
		scope = scope.toLowerCase();
		
		//do check
		checkScopeValue(scope);
		
		setScope(scope);
	}
	
	/**
	 * Checks the scope value, and throws an error if it's
	 * not one of the static values
	 * @throws InvalidScopeException thrown when the scope is not valid 
	 */
	private void checkScopeValue(String scope)
	throws InvalidScopeException
	{
		if(scope.equals(SCOPE_APPLICATION) 
				|| scope.equals(SCOPE_INSTANCE)
				|| scope.equals(SCOPE_NONE)
				|| scope.equals(SCOPE_REQUEST)	
				|| scope.equals(SCOPE_SERVER)
				|| scope.equals(SCOPE_SESSION)
				|| scope.equals(SCOPE_TRANSACTION)
				)
		{
			return;
		}
		
		throw new InvalidScopeException("Scope '"+ scope +"' is invalid as an option");
	}
	
	public int getMaxObjects()
	{
		return maxObjects;
	}

	private void setMaxObjects(int maxObjects)
	{
		this.maxObjects = maxObjects;
	}

	public int getSecondsPersisted()
	{
		return secondsPersisted;
	}

	private void setSecondsPersisted(int secondsPersisted)
	{
		this.secondsPersisted = secondsPersisted;
	}

	public String getScope()
	{
		return scope;
	}

	private void setScope(String scope)
	{
		this.scope = scope;
	}

	public int getSecondsAccessedTimeout()
	{
	    return secondsAccessedTimeout;
	}

	private void setSecondsAccessedTimeout(int secondsAccessedTimeout)
	{
	    this.secondsAccessedTimeout = secondsAccessedTimeout;
	}
	
}
