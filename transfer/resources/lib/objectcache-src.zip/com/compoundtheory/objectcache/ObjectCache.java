package com.compoundtheory.objectcache;

import java.util.*;
import java.lang.ref.*;

import edu.emory.mathcs.backport.java.util.concurrent.ThreadPoolExecutor;

/**
 * Object for persisting ColdFusion CFCs
 * 
 * @author Mark Mandel
 * 
 */
public class ObjectCache extends Observable
{
    private Map cache;
    private Map lookup;
    private int maxNumber;
    private int secondsPersisted;
    private int secondsAccessedTimeout;
    private int requestCycle;

    private String className;
    private ThreadPoolExecutor threadPool;

    private static final int GC_CYCLE_RATE = 10;

    public static final String CLEAR_CFC_KEY = "cfc";
    public static final String CLEAR_SOFTREF_KEY = "softref";

    /**
     * Default constructor of unlimited objects, and always persisted
     */
    public ObjectCache(String className, ThreadPoolExecutor threadPool) throws InvalidScopeException
    {
	this(className, threadPool, new Config());
    }


    /**
     * 
     * 
     * @param maxNumber
     *            Maximum number of objects to cache. 0 is unlimited
     * @param secondsPersisted
     *            Total number of seconds to persist an object. 0 is forever.
     */
    
/**
 * Constructor for a new Object Cache
 * 
 * @param className the name of the class that this cache represents
 * @param threadPool the thread pool
 * @param config the configuration for this cache.
 */
    public ObjectCache(String className, ThreadPoolExecutor threadPool, Config config)
    {
	setMaxNumber(config.getMaxObjects());
	setSecondsPersisted(config.getSecondsPersisted());
	setSecondsAccessedTimeout(config.getSecondsAccessedTimeout());
	setRequestCycle(0);
	setClassName(className);
	setThreadPool(threadPool);

	if (getMaxNumber() > 0)
	{
	    setCache(Collections.synchronizedMap(new HashMap(getMaxNumber())));
	    setLookup(Collections.synchronizedMap(new HashMap(getMaxNumber())));
	}
	else
	{
	    setLookup(Collections.synchronizedMap(new HashMap()));
	    setCache(Collections.synchronizedMap(new HashMap()));
	}
    }

    /**
     * If the cache has the object, and it hasn't expired
     * 
     * @param key
     *            The key to look for the object is stored under
     * @return whether the object exists, and hasn't expired
     */
    public boolean has(String key)
    {
	if (!getCache().containsKey(key))
	{
	    return false;
	}

	CachedObject object = getCachedObject(key);

	if (!object.hasExpired() && object.getCFC() != null)
	{
	    return true;
	}

	// remove it
	clearButNotDiscard(object);
	return false;
    }

    /**
     * Retrieve an object from the cache
     * 
     * @param key
     *            The key to look for
     * @return The CFC that was stored in here
     * @throws ObjectNotFoundException
     *             If the object doesn't exist in the cache, this is thrown
     */
    public Object get(String key) throws ObjectNotFoundException
    {
	incrementRequestCycle();
	checkRunGarbageCollect();

	if (!has(key))
	{
	    throw new ObjectNotFoundException("Object under '" + key + "' not found in this cache, or it may have expired");
	}

	CachedObject cacheobject = getCachedObject(key);
	Object cfc = cacheobject.getCFC();

	if (cacheobject.getCFC() == null)
	{
	    throw new ObjectNotFoundException("Object under '" + key + "' has been picked up by the JVM gabarge collector");
	}

	cacheobject.hit();

	return cfc;
    }

    /**
     * Adds an object to the cache
     * 
     * @param softRef
     *            the soft reference that contains the object
     * @param key
     *            The key to store it under. This should be unique
     */
    public void add(SoftReference softRef, String key)
    {
	// first make sure it's real
	Object object = softRef.get();

	if (object == null)
	{
	    return;
	}

	// discard object if the key exists
	if (getCache().containsKey(key))
	{
	    CachedObject cachedObject = getCachedObject(key);
	    if (cachedObject != null)
	    {
		clearButNotDiscard(cachedObject);
		reap(cachedObject.getCfcSoftRef());
	    }
	}

	// add the object

	// grab a cachedObject from the cache, and configure
	CachedObject cachedObject = new CachedObject(softRef, getSecondsPersisted(), getSecondsAccessedTimeout());

	getLookup().put(softRef, key);
	getCache().put(key, cachedObject);

	incrementRequestCycle();
	// make this do checking on how many currently exist
	checkRunGarbageCollect();
    }

    /**
     * discard a key from the cache
     * 
     * @param key
     *            the key to discard
     */
    public void discard(String key)
    {
	if (getCache().containsKey(key))
	{
	    CachedObject cachedObject = getCachedObject(key);

	    if (cachedObject != null)
	    {
		// we don't do a clearByNotDiscard here, as this actually comes
		// down the discard pipe.
		cachedObject.clear();

		getLookup().remove(cachedObject.getCfcSoftRef());
		getCache().remove(key);
	    }
	}
    }

    /**
     * Checks to see if the garbage collection should be run, and runs it as
     * necessary
     */
    private void checkRunGarbageCollect()
    {
	// no point in creating a thread, if there is nothing to discard.
	if (exceedsMaximumNumber() || exceedsSecondsPersisted())
	{
	    if (getRequestCycle() > GC_CYCLE_RATE)
	    {
		// run garbage collect
		setRequestCycle(0);
		GarbageCollect gc = new GarbageCollect();
		getThreadPool().execute(gc);
	    }
	}
    }
    
    /**
     * clears the object, but doesn't discard it from the cache,
     * just preps it for the discard queue
     * @param object the cached object to clear
     */
    private void clearButNotDiscard(CachedObject object)
    {
	Object cfc = object.getCFC();

	if (cfc != null)
	{
	    HashMap result = new HashMap(2);
	    result.put(CLEAR_CFC_KEY, cfc);
	    result.put(CLEAR_SOFTREF_KEY, object.getCfcSoftRef());

	    setChanged();
	    notifyObservers(result);
	}

	// must be after, so that the cfc can be set before it's enqueued
	object.clear();
    }

    /**
     * Reaps out the soft ref required
     * 
     * @param softRef
     *            the soft ref that has been cleared
     */
    public void reap(SoftReference softRef)
    {
	if (getLookup().containsKey(softRef))
	{
	    String key = (String) getLookup().get(softRef);
	    // do remove here, as it may not happen otherwise
	    getCache().remove(key);
	}

	getLookup().remove(softRef);
    }
    
    /**
     * Returns the estimate size of the cache (fast),
     * does not scan the cache for empty soft references
     * @return the estimated cache size
     */
    public int getEstimatedSize()
    {
	return getCache().size();
    }
    
    /**
     * Returns the calculated size (slow), by
     * looping through a copy of the collection and checking
     * if the soft references are cleared or not
     * 
     * @return the calculated cache size
     */
    public int getCalculatedSize()
    {
	//get a copy, so it doesn't change while we're working
	ArrayList cache = new ArrayList(getCache().values());
	int size = 0;
	
	Iterator iterator = cache.iterator();
	
	while(iterator.hasNext())
	{
	    CachedObject cachedObject = (CachedObject)iterator.next();
	    Object o = cachedObject.getCFC();
	    
	    if(o != null)
	    {
		size++;
	    }
	}
	return size;
    }
    

    /**
     * Returns whether or not the size of the cache possibly exceeds the maximum
     * size.
     * 
     * @return
     */
    private boolean exceedsMaximumNumber()
    {
	if (getMaxNumber() == Config.UNLIMITED_OBJECTS)
	{
	    return false;
	}
	else if (getMaxNumber() < getCache().size())
	{
	    return true;
	}

	return false;
    }

    private boolean exceedsSecondsPersisted()
    {
	if (getSecondsPersisted() == Config.UNLIMITED_SECONDS)
	{
	    return false;
	}

	// NOTE: may look at tracking the min() date accessed CachedObject

	return true;
    }

    private CachedObject getCachedObject(String key)
    {
	return (CachedObject) getCache().get(key);
    }

    private Map getCache()
    {
	return cache;
    }

    private void setCache(Map cache)
    {
	this.cache = cache;
    }

    private Map getLookup()
    {
	return lookup;
    }

    private void setLookup(Map lookup)
    {
	this.lookup = lookup;
    }

    private int getMaxNumber()
    {
	return maxNumber;
    }

    private void setMaxNumber(int maxNumber)
    {
	this.maxNumber = maxNumber;
    }

    private int getSecondsPersisted()
    {
	return secondsPersisted;
    }

    private int getSecondsAccessedTimeout()
    {
	return secondsAccessedTimeout;
    }

    private void setSecondsAccessedTimeout(int secondsAccessedTimeout)
    {
	this.secondsAccessedTimeout = secondsAccessedTimeout;
    }

    private void setSecondsPersisted(int secondsPersisted)
    {
	this.secondsPersisted = secondsPersisted;
    }

    private int getRequestCycle()
    {
	return requestCycle;
    }

    private void setRequestCycle(int requestCycle)
    {
	this.requestCycle = requestCycle;
    }

    private void incrementRequestCycle()
    {
	setRequestCycle(getRequestCycle() + 1);
    }

    private String getClassName()
    {
	return className;
    }

    private void setClassName(String className)
    {
	this.className = className;
    }

    private ThreadPoolExecutor getThreadPool()
    {
	return threadPool;
    }

    private void setThreadPool(ThreadPoolExecutor threadPool)
    {
	this.threadPool = threadPool;
    }

    /**
     * Garbage collect class for async collections Doesn't actually discard
     * objects, pushes them out to a queue to be discarded by CF
     * 
     * @author Mark Mandel
     * 
     */
    private class GarbageCollect implements Runnable
    {
	public GarbageCollect()
	{
	    // nothing much here
	}

	/**
	 * Thread method for running the garbage collection process
	 */
	public void run()
	{
	    // first, let's expire objects that are expired
	    // gimme a local copy, in AN order

	    LinkedList localCache = new LinkedList(getCache().values());

	    // just escape out if we don't need to expire objects
	    if (exceedsSecondsPersisted())
	    {
		Iterator iterator = localCache.iterator();

		while (iterator.hasNext())
		{
		    CachedObject object = (CachedObject) iterator.next();

		    if (object.hasExpired())
		    {
			iterator.remove();
			clearButNotDiscard(object);
		    }
		}
	    }

	    /*
	     * now, if we're over the legal number of items, let's do some smart
	     * stuff to get rid of the least used items -
	     * 
	     * Basically, build a roullette wheel, by each object's fitness and
	     * do a random remove until we have removed as many as we should
	     */
	    if (getMaxNumber() != Config.UNLIMITED_OBJECTS && getMaxNumber() < localCache.size())
	    {
		int amount = localCache.size() - getMaxNumber();

		for (int counter = 0; counter < amount; counter++)
		{
		    CachedObject object = popFromRoulleteWheel(localCache);
		    if (object == null)
		    {
			System.out.println("ObjectCache [" + getClassName() + "]: How is the discard object null?");
		    }
		    else
		    {
			localCache.remove(object);
			clearButNotDiscard(object);
		    }
		}
	    }
	}

	/**
	 * Builds a weighted roullette wheel from a snapshot of the current
	 * object's fitness's, and then selects one from a spin
	 * 
	 * @param list
	 *            The list of objects to remove from
	 * @return The CachedObject that was pop'd
	 */
	private CachedObject popFromRoulleteWheel(LinkedList list)
	{
	    long sumFitness = 0;

	    // use this to make those less fit, go first
	    int maxFitness = 0;

	    int[] fitnessSnapShot = new int[list.size()];
	    Iterator iterator = list.iterator();

	    int counter = 0;
	    while (iterator.hasNext())
	    {
		CachedObject object = (CachedObject) iterator.next();
		int fitness = object.calculateFitness();

		if (maxFitness < fitness)
		{
		    maxFitness = fitness;
		}

		fitnessSnapShot[counter] = (fitness);
		counter++;
	    }

	    Double doubleRandValue = new Double(Math.random() * sumFitness);

	    int randValue = Math.round(doubleRandValue.floatValue());

	    int currentValue = 0;

	    iterator = list.iterator();

	    counter = 0;

	    while (iterator.hasNext())
	    {
		CachedObject object = (CachedObject) iterator.next();

		// switch this around, so those with high fitness are least
		// likely to be removed.
		currentValue += (maxFitness - fitnessSnapShot[counter]);

		if (currentValue >= randValue)
		{
		    return object;
		}

		counter++;
	    }

	    return null; // this is bad, and should not happen
	}
    }
}
