package com.compoundtheory.objectcache;

import java.lang.ref.SoftReference;
import java.util.*;

/**
 * This is a dummy class that pretty much does nothing
 * @author Mark Mandel
 *
 */
public class DummyCacheManager implements ICacheManager
{
	/**
	 * Constructor
	 * @param config does nothing with this
	 */
	public DummyCacheManager(CacheConfig config)
	{
		//does nothing
	}	
	
	/**
	 * Goes nowhere
	 */
	public void add(String clazz, String key, SoftReference softRef)
	{
		//does nothing
	}
	
	/**
	 * Doesn't discard, as it holds nothings 
	 */
	public void discard(String clazz, String key)
	{
		//nothing to discard
	}

	/**
	 * Will always throw a ObjectNotFoundException
	 */
	public Object get(String clazz, String key)
			throws ObjectNotFoundException
	{
		throw new ObjectNotFoundException("Object will never exist in the DummyCacheManager");
	}

	/**
	 * Never has anything
	 */
	public boolean has(String clazz, String key)
	{
		return false;
	}

	/**
	 * Does nothing
	 */
	public void reap(String clazz, SoftReference softRef)
	{
		//does nothing
	}
	
	/**
	 * returns null
	 */
	public Object popReapedCFC(SoftReference softRef)
	{
	    return null;
	}
	
	/**
	 * returns an empty set
	 */
	public Set getCachedClasses()
	{
	    return new HashSet();
	}
	
	
}
